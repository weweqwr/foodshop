package foodshop1;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import org.springframework.context.ApplicationContext;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.foodshop.pojo.User;
import com.foodshop.service.user.UserService;

public class UserTest {

    private Logger logger = Logger.getLogger(UserTest.class);

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testGetUserList() throws Exception {
        ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        User userCondition = new User();
        userCondition.setUserName("111");
//        userCondition.setPassWord("123456");
     
       
//        userList=userService.showGoods(userCondition);
       userService.addGb(userCondition);
//        userService.addUser(userCondition);
        
//        System.out.println(userList.size()==0);
//        for (User userResult : userList) {
//            logger.debug("===================================================="
////                    + userResult.getGoodsName() 
//                    +userResult.getGoodsName()
////                    +userResult.getPrice()
//                    );
//        }
    }

}
