package foodshop1;

import java.util.ArrayList;
import java.util.List;

import com.foodshop.pojo.User;
import com.foodshop.service.user.Sub;

public class test {

	public static void main(String[] args) {
		String a="111,222,333,444,555";
		List<String> list=new ArrayList<String>();
		Sub s=new Sub();
		list=s.sub(a);
		for(int i=0;i<list.size();i++) {
			System.out.println(list.get(i));
		}
	}

}
