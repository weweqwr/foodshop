package foodshop1;

import java.io.IOException;

import com.RestTest;

public class test2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
//		RestTest rs=new RestTest();
//		rs.PhoneCheck("13924768186", "1111");

	}

}
