/**
 * Created by linhai on 2016/5/28.
 */
function addZero(value){
	return value <10 ? '0'+value : value;
}
function formatSeconds(value) {
	var theTime = parseInt(value);// 秒
	var mins = 0;// 分
	var hour = 0;// 小时
	if(theTime >= 60) {
		mins = parseInt(theTime/60);
		theTime = theTime%60;
		if(mins >= 60) {
			hour = parseInt(mins/60);
			mins = mins%60;
		}
	}
	return  addZero(hour)+":"+addZero(mins)+":"+addZero(theTime);
}


var topValue = 0,// 上次滚动条到顶部的距离
	interval = null,// 定时器
	_numBar = true,
	_sTop = 0,
	_page=0,
	_turnPage = $('#turnpage'),
	sCity='',
	sProvince='';
var _linkHeader = requestHeader();
//记录滚动条的高度
$(window).scroll(function(){
	_sTop = $(window).scrollTop();
})

$(function(){

	// 搜索
	var _searchUrl = $('#search-url').val();

	$(".search-btn").click(function(){
		turnLink(_searchUrl);
	})

	var _winW = $(window).width();

	if( _winW > 640){
		_winW = 640;
	}

	$(".home-box").width(_winW);
	$(window).resize(function () {
		var _winW = $(window).width();
		if( _winW > 640){
			_winW = 640;
		}
		$(".home-box").width(_winW);
	})
	function getPosition(){//城市定位
		$.ajax({
			url:'https://api.map.baidu.com/location/ip?ak=fsC2OdU6KFE2kiKBbHWQFtFuITMCthdy',
			dataType:'jsonp',
			jsonp:'callback',
			async:false,
			success:function(data){
				if(data && window.localStorage){
					sCity=data.content.address_detail.city;
					sProvince=data.content.address_detail.province;
					window.localStorage.setItem('city',sCity);
					window.localStorage.setItem('province',sProvince);
				}
			}
		})
	}
	if(!window.localStorage.getItem('city')){
		getPosition();
	}else{
		sCity=window.localStorage.getItem('city');
		sProvince=window.localStorage.getItem('province');
	}
	// try{

		/*
		 * 导航事件
		 * 点击滚动到对应内容块
		 * 滚动到内容块显示相应的导航状态
		 * lihai
		 */
		var _top = 0,_scrollTop = 0,_berserkTop,_todayTop,_recommendTop,_hotTop,_titTop,_onScroll = false,
			_win = $(window),
			_class = $('.home-class'),
			_nav = $("#home-nav"),
			_berserk = $('.nav-berserk'),
			_today = $('.nav-today'),
			_recommend = $('.nav-recommend'),
			_hot = $('.nav-hot'),
			_berserkList = $('.berserk-product'),
			// _hotList = $('.hot-product'),
			// _swiper = $('.swiper-container'),
			// _newbie = $('.newbie-product'),
			// _berserkTit = $('.berserk-tit'),
			_turnId = $('#turnid').val(),
			listCount=0,
			//_page=0,
		    isLoad=false,
		    ismore=0,
		    pageCount=10,
		    beforePage=_turnPage.val(),
		    i=0,
		   // _listH=0,
		    //_scrollH=0,
		    _loading=$('.load1');

		var _classUrl = $('#class-url').val(),
			_infoBox = $(".home-info"),
			_infoHtml = $("#table-template").html(),
			_navHtml = $("#nav-template").html(),
			_homeBoxHtml= $("#home-box-template").html(),
			_greatSaleHtml=$("#greatSale-template").html(),
			_template = '',_classSwiper = '',_pagination = '',
			_turnH = $('#turnheight'),
			_initScroll = true,countCurrent = $(".currentcount");
		//初始化对应的值
		_scrollTop = _win.scrollTop();
		getIndexDate(function(){
			var sreenW=window.screen.width>640 ? 640 : window.screen.width,
				$banner=$('.banner');
			$banner.each(function(index){
				var allImgW=0;
				for(var i=0;i<$(this).find('a').length;i++){
					allImgW=allImgW+parseInt($(this).find('a').eq(i).attr('data-width'));

				}
				for(var i=0;i<$(this).find('a').length;i++){
					var w=sreenW*parseInt($(this).find('a').eq(i).attr('data-width'))/allImgW;
					$(this).find('a').eq(i).css({'width':w})
				}
			})
            if(isWeiXin()){
                $('.share-link-wrap').hide();
            }

			//处理导航
			// navFunSwiper(_turnId);
			mySwiper();
			// setTimeout(function(){
			// 	_nav.find("a").eq(_turnId).click();
			// },200)
			var _navBtn = _nav.find("a"),
				_boxHtml = '<div class="home-box dp-none" data-status = "0"><p class="t_c mt-50 ">正在加载…</p></div>';
			//初始化跟导航对应的内容box
			for(var i = 0;i < _navBtn.length - 1; i++){
				_infoBox.append(_boxHtml);
			}
			if($('.swiper-notice .swiper-slide ').length>1){
				var swiper = new Swiper('.swiper-notice', {
			        autoplayDisableOnInteraction:false,
			        loop:true,
			        autoplay:4000,
			        direction: 'vertical'
			    });
			}
			isShowTop();
			greatSaleDate(_page);
		});
		scrollFun();
		// var navSwiper = '';
		// function navFunSwiper(_index){
		// 	navSwiper = new Swiper('.home-nav',{
		// 		initialSlide :_index,
		// 		slidesPerView : "auto",
		// 		freeMode : true,
		// 		freeModeSticky : true
		// 	});
		// }
		// _nav.on('click','a',function(){
		// 	var _this = $(this),
		// 		i = _this.index(),
		// 		_navImg = _this.find('.init-img').attr('src'),
		// 		_navCheckImg = _this.data('checkimg');
		// 	var _countTop = 0;

		// 	if(!_navCheckImg){
		// 		$(this).find('.init-checkimg').attr('src',_navImg)
		// 	}
		// 	navFunSwiper(i);
		// 	stateClass(_this);
		// 	listDataFun(_this);

		// 	if(i == 0){
		// 		_numBar = true;
		// 	}else{
		// 		_numBar = false;
		// 	}

		// })
		function getIndexDate(callback){
			$.ajax({
				url:_linkHeader+'/homePage/homeInfo?'+ linkTidFun(),
				data:{city:sCity,province:sProvince},
				type:'post',
				success:function(data){
					if(data.status == 4){//处理微信调用接口缓存授权问题
						var _link = window.location.href;

						if(_link.indexOf('?') > -1){
							window.location.href = _link + '&cache='+Math.round(Math.random()*100);
						}else{
							window.location.href = _link + '?cache='+Math.round(Math.random()*100);
						}
					}

					$('.load').hide();

                    try {//微信分享
                        brandShareFun(data.shareData)
                    } catch (err) {
                    }

					// 导航数据填充
					// var _template = Handlebars.compile(_navHtml);
					// $("#home-nav").html(_template(data));
					// if(data.dailyBerserk){
					// 	var endSecond=data.dailyBerserk.endSecond;	
					// 	var endtime=formatSeconds(data.dailyBerserk.endSecond);
					// 	data.dailyBerserk.hour=endtime.split(':')[0];
					// 	data.dailyBerserk.min=endtime.split(':')[1];
					// 	data.dailyBerserk.sec=endtime.split(':')[2];															
					// }
					
					//数据填充
					var _template = Handlebars.compile(_homeBoxHtml);
					$(".home-box .homeMain").html(_template(data));
					if(data.dailyBerserk){
						var endSecond=data.dailyBerserk.endSecond
						var timer=setInterval(function(){
							if(endSecond<0){
								endSecond=0;
								clearInterval(timer);
								$('.cuntdown span').html('00');
							}else{
								endSecond--;
								var endtime=formatSeconds(endSecond);	
								$('.cuntdown span:eq(0)').html(endtime.split(':')[0]);
								$('.cuntdown span:eq(1)').html(endtime.split(':')[1]);
								$('.cuntdown span:eq(2)').html(endtime.split(':')[2]);
							}
						},1000)	
					}	

					var _bannerTurn = $(".banner a,.pushoumoudle a,.giftPack a");

					_bannerTurn.click(function(){
						var _url = $(this).data("url");
						// _turnH.val(_sTop);
						turnLink(_url);
					})

					//选中城市
					if((data.showName && data.showName=='全国') || !data.showName){
						$('.city-btn i').html('请选择')
					}else{
						$('.city-btn i').html(data.showName)
					}

					// _hotTop = _berserkList.offset().top - _nav.height() - 10;

					// $(window).scrollTop(_turnH.val());

					activityTan();

					callback && callback();
				},
				error: function(){
					//alert(data.meg)
				}
			})
		}
		function greatSaleDate(page,callback){//加载热卖推荐数据
			$.ajax({
				url:_linkHeader+'/homePage/greateSale',
				type:'post',
				data:{'page':page,'pageCount':pageCount},
				success:function(data){
					_berserkList.show();
					// $('.load').hide();
					isLoad=false;
					_loading.hide();
					var _listdata=data.greatSale;
					if(_listdata.length>0 && page==0){
						$('.hot-product-tlt').show();
					}
					_listdata.forEach(function(value,index){
						_listdata[index].currPage=data.currPage
					})
					//数据填充
					var _template = Handlebars.compile(_greatSaleHtml);
					$(".hot-product .load1").before(_template(data));
					listCount=data.totalCount;
					var totalPgae=listCount/pageCount;
					if(_numBar){
						countTxt.text(listCount);
					}
					if(_page>=totalPgae-1){
	                    ismore = 1;
	                    $('.list-end').show();
	                }else{
	                   ismore = 0;
	                   $('.list-end').hide();
	                }
					var test = setTimeout(function(){
						$(".imglazyload").picLazyLoad({//图片懒加载
							threshold: 600,
							placeholder: ''
						});
					},200);
					if(_initScroll && _turnH.val() && beforePage !=0 && _turnId==0){
						i++;
						if(i<=beforePage){
							_page=i;
							greatSaleDate(i);
						}
					}
					if(page==beforePage && _initScroll && _turnId==0){
						$(window).scrollTop(_turnH.val());
						_initScroll = false;
					}

					hotProductClick();
					_hotTop = _berserkList.offset().top - _nav.height() - 10;

					callback && callback();
				},
				error: function(){
				}
			})
		}
		function scrollFun(){ //滚动加载分页数据
	        var _scrollH,_listH,windowH=$(window).height();

	         $(window).scroll(function (){
	                _scrollH = $(window).scrollTop() + windowH;
	                _listH=$(".home-box").height();
	            if(_scrollH >= _listH-30 && ismore == 0 && ! isLoad){
	                //console.log(_page)
	                _page += 1;
	                _loading.show();
	                isLoad=true;
	                setTimeout(function(){
	                    greatSaleDate(_page);
	                },500)
	            }
	        })
	    }
	    function hotProductClick(){
	    	$('.hot-product').off();
	    	$('.hot-product').on('click','.berserk-info',function(e){
	    		var page=$(this).attr('data-page'),
	    			url=$(this).attr('data-url');
	    		//console.log(page);
	    		_turnPage.val(page);
	    		turnLink(url);
	    	})
	    }
		//状态切换
		function stateClass(_class){
			_class.addClass('on').siblings().removeClass("on");
		}

		//滚动时显示对应的导航状态
		function classScroll(scroll){
			if(scroll < _berserkTop){
				_nav.find("a").removeClass("on");
			}else if( _berserkTop <= scroll && scroll < _todayTop){
				stateClass(_berserk);
			}else if(_todayTop <= scroll && scroll < _recommendTop){
				stateClass(_today);
			}else if(_recommendTop <= scroll && scroll < _hotTop){
				stateClass(_recommend);
			}else if(_recommendTop <= scroll ){
				stateClass(_hot);
			}
		}
		// classScroll(_scrollTop);

		//窗口滚动时事件处理
		var list = $(".hot-product ul"),
			//listCount = list.length,
			countTxt = $(".listall"),
			//countCurrent = $(".currentcount"),
			//listTop = _hotTop + 100,
			differTop = 0,endTop = 0,count = 0,
			//listH = list.height() + 50,
			//startnum = parseInt($(window).height()/listH),
			//otherH = listTop  - listH/2,
			endH = $("body").height() - $(window).height();

		function isShowTop(){
			var list = $(".hot-product ul"),
				//countCurrent = $(".currentcount"),
				listTop = _hotTop + 100,
				listH = list.height() + 50,
				startnum = parseInt($(window).height()/listH),
				otherH = listTop  - listH/2;
			if(_numBar){
				if(_scrollTop > listTop){
					startnum = parseInt((_win.height() + _scrollTop - otherH)/listH);

					if(startnum > listCount){
						startnum = listCount;
					}
				}
			}
			countCurrent.text(startnum);
		}
		//判断返回顶部
		function backTop(){
			if(_scrollTop > 500){
				$('.topbar').fadeIn();
			}else{
				$('.topbar').fadeOut();
			}
		}

		backTop();
		numcountFun();
		function numcountFun(){
			_win.scroll(function(){
			_scrollTop =_win.scrollTop();

				$("#turnheight").val(_scrollTop);

				//判断返回顶部
				backTop();

				if(_numBar) {
					if (_scrollTop > (_hotTop - _win.height() / 2)) {
						$(".listcount").show().prev().hide();
					} else {
						$(".listcount").hide().prev().fadeIn();
					}
				}
				// //根据滚动的距离显示商品的数额
				if(interval == null)// 未发起时，启动定时器，1秒1执行
					interval = setInterval("onCount()", 1000);
				topValue = document.documentElement.scrollTop;

				var countP = 1;
				var _berserkInfo = $(".home-class .berserk-info");
				_berserkInfo.each(function(i){
					var top = parseInt(_berserkInfo.eq(i).offset().top + $('#footBar').height() + 50),
						_height =top - parseInt(_scrollTop + _win.height());

					if(_height <= 0 ){
						countP = $(this).index();
					}
				})
				countCurrent.text(countP);
			});
		}

		//返回顶部
		$('.topbar').click(function(){
			$('html,body').animate({scrollTop:'0'},800);
			return false;
		});

		//滑动时显示商品数量
		touch.on("body","dragstart drag",function(){
			if( _scrollTop < (_hotTop - _win.height()/2)) return false;
			if(_numBar){
				$(".listcount").show().prev().hide();
			}
		})

		touch.on("body","dragend",function(){
			if(_scrollTop == endH){
				$(".listcount").hide().prev().fadeIn();
			}
		})

		function listDataFun(_this){
			var _index = _this.index(),
				_classId = _this.data("id"),
				_classType = _this.data("type"),
				_classStatus = $(".home-box").eq(_index).attr("data-status"),
				_data = '';
			if(_index != 0){
				$(window).scrollTop(0);
			}

			$(".home-box").eq(_index).show().siblings(".home-box").hide();

			if(_classType == 3){
				// $("#turnid").val(0);
				//处理ios下返回无刷新产生的加载问题
				_turnId = $('#turnid').val(),
				_nav.find("a").eq(_turnId).click();

			}else{
				$("#turnid").val(_index);
			}

			if(_index == 0 || _classStatus == 1) return false;

			$.ajax({
				url:_linkHeader+_classUrl,
				type:'post',
				data:{
					id:_classId
				},
				success:function(data){
					if(_classType == 3) return false;
					if(data.status == 1){
						//                            console.log(data);
						_data = data;
						_template = Handlebars.compile(_infoHtml);
						$(".home-box").eq(_index).html(_template(_data)).attr("data-status",'1');

						_classSwiper = $(".home-box").eq(_index).find('.class-swiper');
						_pagination = $(".home-box").eq(_index).find(".pagination-class");
						var _classSwiperName = 'swclass' + _index,
							_paginationName = 'swnum'+ _index;

						_classSwiper.addClass(_classSwiperName);
						_pagination.addClass(_paginationName);
						_classSwiperName = '.'+_classSwiperName;
						_paginationName = '.'+_paginationName;

						if(_data.bannerList.length > 1){
							classSwiper(_classSwiperName,_paginationName);
						}

						$(".class-info-list a").click(function(){
							var _link = $(this).data('link');
							_turnH.val(_sTop);
							setTimeout(function(){window.location.href = _link},500)
						})

						if(_initScroll){
							$('body').scrollTop(_turnH.val());
							_initScroll = false;
						}
					}else{
						console.log('请求出错');
					}
				}
			})
		}

	// }catch(err){
	// 	console.log(12)
	// }

	//公众号
	// var _gzh = $(".gzhao"),
	// 	_gzhH = _gzh.height(),
	// 	_pH = _nav.height() + _gzhH,
	// 	_ewm = $('.ewm-tan');
    //
	// if(_gzhH){
	// 	console.log(_gzhH);
	// 	_nav.css("top",_gzhH);
	// 	$('.pt-46').css({'padding-top':_pH});
	// 	_gzh.click(function(){
	// 		_ewm.show();
	// 		$('.mask-full').show();
	// 	})
	// 	closeFun(_ewm);
	// }

	//选择省市
	var _cityBtn = $(".city-btn"),
		_cityBox = $(".city-box"),
		_addressUrl = $("#address-url").val(),
		_addressUrl2 = $('#address-url2').val(),
		_addressUrl3 = $('#address-url3').val(),
		_addressBox = $(".city-html"),
		_addressList = $('#address-template').html(),
		_addrTemplate = Handlebars.compile(_addressList);

	window.onhashchange = function(){
		var _hash = window.location.hash;
		// console.log(_hash);
		if(_hash == ''){
			_cityBox.hide();
		}
	}

	_cityBtn.click(function(){
		_cityBox.show();
		window.location.hash = '#cityList';
		getPosition();
		//调用收货地址，热门城市接口
		$.ajax({
			url:_linkHeader+_addressUrl,
			type:'post',
			data:{city:sCity,province:sProvince},
			success:function(data){
				// console.log(data);

				_addressBox.html(_addrTemplate(data));

				$(".city-jump").click(function(){
					var _this = $(this),
						_id = _this.data('id'),
						_cityId = _this.data('cityid'),
						_name = _this.text(),
						_showName = _this.data('name');

					reloadFun(_id,_cityId,_showName);
				})
				$(".city-name,.city-current").click(function(){
					var _this = $(this),
						_id = _this.data('id'),
						_cityId = _this.data('cityid'),
						_name = _this.text();

					if(_name == '定位失败'){
						_this.text('定位中…');
						setTimeout(function(){_this.text('定位失败')},1000);
						return false;
					}

					reloadFun(_id,_cityId,_name);
				})

			}
		})

		//处理城市分组
		var _cityInfoBox = $(".city-info"),
			_cityInfoHtml = $("#city-template").html(),
			_infoTemplate = Handlebars.compile(_cityInfoHtml);

		_cityInfoBox.html(_infoTemplate(cityInfoFun()))

		$(".city-list li").click(function(){
			var _this = $(this),
				_id = _this.data('id'),
				_name = _this.text();
			reloadFun(_id,0,_name);
		})

	})

	//去除重复地址，返回地址列表
	Handlebars.registerHelper("addressList",function(list,options){
		var _listData = [],
			_data = [],
			_json = {},
			_listHtml = '';

		for(var i = 0; i < list.length; i++){
			var _id = list[i].province,
				_cityId = list[i].city,
				_name = list[i].nationWide,
				_showName = list[i].showName;
			_listData.push({
				id:_id,
				cityId:_cityId,
				name:_name,
				showName:_showName
			});
		}

		//去重
		for(var j = 0; j < _listData.length; j++){
			if(!_json[_listData[j].name]){
				_data.push(_listData[j]);
				_json[_listData[j].name] = 1;

				var _id = _listData[j].id,
					_cityId = _listData[j].cityId,
					_name =_listData[j].name,
					_showName = _listData[j].showName;

				if(j == 0){
					_listHtml = '<li class="city-jump" data-id = '+_id+' data-cityid='+_cityId+' data-name ='+_showName+'>'+_name+'<i class="f-12 ml-10 col-888">默认地址</i></li>';
				}else{
					_listHtml += '<li class="city-jump" data-id = '+_id+' data-cityid='+_cityId+' data-name ='+_showName+'>'+_name+'</li>';
				}
			}
		}
		return _listHtml;
	});

	Handlebars.registerHelper("dingWei",function(obj,options){
		if(obj == '全国'){
			return options.fn(this);
		}else{
			return options.inverse(this);
		}
	})
	Handlebars.registerHelper('exp',function(){
		var exps = [];
        try{
            //最后一个参数作为展示内容，也就是平时的options。不作为逻辑表达式部分
            var arg_len = arguments.length;
            var len = arg_len-1;
            for(var j = 0;j<len;j++){
                if(arguments[j]=='=='||arguments[j]=='>='||arguments[j]=='<='||arguments[j]=='>'||arguments[j]=='<'||arguments[j]=='!='||arguments[j]=='||'||arguments[j]=='&&'){
                    exps.push(arguments[j]);
                }else{
                    exps.push('"'+arguments[j]+'"');
                }
            }
            var result = eval(exps.join(' '));
            if (result) {
                return arguments[len].fn(this);
            } else {
                return arguments[len].inverse(this);
            }
        }catch(e){
            throw new Error('Handlerbars Helper "expression" can not deal with wrong expression:'+exps.join(' ')+".");
        }
	})

	//定位刷新页面调用方法
	function reloadFun(id,cityId,name){
		var _location = window.location.href;
		$.ajax({
			url:_linkHeader+_addressUrl2,
			type:'post',
			data:{
				province:id,
				city:cityId,
				showName:name
			},
			success:function(data){
				window.location.reload(_location);

			}
		})
	}


	// 底部导航
	var _index = $("#navFooterToPage").val();
	$("#footBar").find("a").eq(_index).addClass("current").siblings().removeClass("current");
	if(loginLoad()){
		$.ajax({
			type:'POST',
			url: _linkHeader+'/spcart/showcartcount',
			dataType: 'json' ,
			success: function(msg){
				if(msg.cartCount > 0){
					$(".carNum").show().text(msg.cartCount);
				}
			},
			error:function(err){
				$(".carNum").text(0);
			}
		});
	}

});

function onCount() {
	// 判断此刻到顶部的距离是否和1秒前的距离相等
	if(document.documentElement.scrollTop == topValue) {
		$(".listcount").hide().prev().fadeIn();
		clearInterval(interval);
		interval = null;
	}
}

function mySwiper(){
	var mySwiper = new Swiper('.home-swiper ',{
		pagination: '.pagination',
		paginationClickable: true,
		moveStartThreshold: 100,
		autoplayStopOnLast:true,
		autoplayDisableOnInteraction:false,
		loop:true,
		autoplay:4000,
		moveStartThreshold:0.1,
	});
	var swiper = new Swiper('.berserk-swiper-container', {
        slidesPerView: 'auto',
        freeMode: true,
    });

}

function classSwiper(_class,_pagination){
	var classSwiper = new Swiper(_class,{
		pagination: _pagination,
		paginationClickable: true,
		moveStartThreshold: 100,
		autoplayStopOnLast:true,
		autoplayDisableOnInteraction:false,
		loop:true,
		autoplay:4000,
		moveStartThreshold:0.1
	});
}
//链接跳转
function turnLink(url){
	window.location.href = url
}

//首页活动图

function activityTan(){
	var _activity = $(".activity-tan"),
		_mask = $(".mask-full"),
		_mask2 = $(".mask-full2"),
		// _close = $(".close-tb"),
		// _month = new Date().getMonth() + 1,
		// _day = new Date().getDate(),
		// _notice = $(".notice-tan"),
		_repeat = _activity.data("repeat"),
		_id = _activity.data("id") ;

	if(localStorage.activityId){//不同id（说明换商品了）-----展示
		var _activityId = localStorage.activityId;
		// console.log(_activityId);
		if(_id != _activityId){
			_activity.show();
			_mask2.show();
			closeFun(_activity);
			localStorage.activityId = _id;
		}
	}else{//首次进入记录id
		window.localStorage.setItem('activityId',_id);

	}

	if(localStorage.activityMS){//缓存存在 判断是否显示_repeat=1展示

		// console.log(localStorage.activityMS);
		if(_repeat == 1){
			_activity.show();
			_mask2.show();
			closeFun(_activity);
		}
	}else{//首次展示，存值进缓存

		window.localStorage.setItem('activityMS',1);
		_activity.show();
		_mask2.show();
		closeFun(_activity);
	}

}

function closeFun(box){
	var _mask = $(".mask-full"),
		_mask2 = $(".mask-full2"),
		_close = $(".close-tb");

	_close.click(function(){
		box.hide();
		_mask.hide();
		_mask2.hide();
	})
	_mask.click(function(){
		box.hide();
		_mask.hide();
		_mask2.hide();
	})
	_mask2.click(function(){
		box.hide();
		_mask2.hide();
	})
}

//城市分类数据处理
function cityInfoFun(){
	var _cityLetter = ['A','B','C','D','E','F','G','H','J','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'],
		_cityInfoData = [],_cityObj = {},
		_cityListInfo = [
			{
				id:'110000',
				name:'北京'
			},{
				id:'120000',
				name:'天津'
			},
			{
				id:'130000',
				name:'河北'
			},
			{
				id:'140000',
				name:'山西'
			},
			{
				id:'150000',
				name:'内蒙古'
			},
			{
				id:'210000',
				name:'辽宁'
			},
			{
				id:'220000',
				name:'吉林'
			},
			{
				id:'230000',
				name:'黑龙江'
			},
			{
				id:'310000',
				name:'上海'
			},
			{
				id:'320000',
				name:'江苏'
			},
			{
				id:'330000',
				name:'浙江'
			},
			{
				id:'340000',
				name:'安徽'
			},
			{
				id:'350000',
				name:'福建'
			},
			{
				id:'360000',
				name:'江西'
			},
			{
				id:'370000',
				name:'山东'
			},
			{
				id:'410000',
				name:'河南'
			},
			{
				id:'420000',
				name:'湖北'
			},
			{
				id:'430000',
				name:'湖南'
			},
			{
				id:'440000',
				name:'广东'
			},
			{
				id:'450000',
				name:'广西'
			},
			{
				id:'460000',
				name:'海南'
			},
			{
				id:'500000',
				name:'重庆'
			},
			{
				id:'520000',
				name:'四川'
			},
			{
				id:'530000',
				name:'贵州'
			},
			{
				id:'530000',
				name:'云南'
			},
			{
				id:'540000',
				name:'西藏'
			},
			{
				id:'610000',
				name:'陕西'
			},
			{
				id:'620000',
				name:'甘肃'
			},
			{
				id:'630000',
				name:'青海'
			},
			{
				id:'640000',
				name:'宁夏'
			},
			{
				id:'650000',
				name:'新疆'
			}
		];

	//转化对比词语首字母进行分组
	function getItem(letter,list){
		var arr = [];
		list.map(function(item){
			var name = makePy(item.name)[0];

			if(name == letter){
				arr.push(item);
			}
		})
		return arr;
	}

	//把分组好的数据封装为可用对象
	function cityInfoData(list,letter){
		var arr = [];
		letter.map(function (item) {
			var resArr = getItem(item,list);
			if(resArr.length > 0){
				arr.push({
					letter:item,
					list:resArr
				})
			}
		})
		return arr;
	}

	_cityInfoData = cityInfoData(_cityListInfo,_cityLetter);
	_cityObj.cityData = _cityInfoData;

	return _cityObj;
}

//判断是否为微信环境
function isWeiXin(){
	var ua = window.navigator.userAgent.toLowerCase();
	if(ua.match(/MicroMessenger/i) == 'micromessenger'){
		return true;
	}else{
		return false;
	}
}
$('.home-box').on('click','.share-link-wrap',function(){
	var sharePath=$(this).attr('data-href');
	copy(sharePath)
})