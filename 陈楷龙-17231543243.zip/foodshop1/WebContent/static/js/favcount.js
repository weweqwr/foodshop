/**
 * Created by linhai on 2016/9/28.
 */
$(function () {
    var _curDate = new Date(),
        _time = _curDate.getTime(),
        _zeroTime = new Date(_curDate.toLocaleDateString()).getTime() - 1;

    // 收藏cookie
    if(parseInt($.cookie('countFav')) >= 0 ){
    }else{
        $.cookie('countFav',0,{ expires:2,path: '/'});
        $.cookie('countFavCreate',_time,{ expires:2,path: '/'});
    }
})