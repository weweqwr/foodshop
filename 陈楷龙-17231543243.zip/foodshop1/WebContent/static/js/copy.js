function copy(url){
	var u_agent=navigator.userAgent.toLowerCase();
	var el_tag='div';
	if(u_agent.indexOf('oppo')>-1||u_agent.indexOf('sm-')>-1){   
		el_tag='textarea';
	}
	Dlg.show({
		id: 'icustom', 
		content: '<div style="padding:30px;text-align:center;"><p style="font-size: 16px;color: #9E9E9E;">分享链接已生成<br/></p><'+el_tag+' id="foo" readonly="readonly" style="margin-top:30px;color:#1a1a1a;font-size:15px;width:100%;min-height:80px;word-break: break-all;overflow:hidden;">'+url+'</'+el_tag+'> <div id="copylink" style="display: inline-block;" data-clipboard-target="#foo">复制链接</div></div>',
		template: false,
		quickClose: true,
		showClose: true,
		callback: function(){
			var btn = document.getElementById('copylink');
			var clipboard = new ClipboardJS(btn);
			clipboard.on('success', function(e) {
				e.clearSelection();
				Dlg.msg({
					content: '复制成功',
					msgType: "inverse"
				});
			});
			clipboard.on('error', function(e) {
				e.clearSelection();
				Dlg.msg({
					content: '复制失败，长按链接即可复制',
					msgType: "error"
				});
			});
		}
	});
}