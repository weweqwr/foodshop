/**
 * Created by Administrator on 2017/8/3.
 */

// var _loginType = getCookie("QQBSLG409292508"),
//     _currentLink = window.location.href,
//     _encodeLink = encodeURIComponent(_currentLink),
//     _loginUrl = '/hp/login.html?redirect_url='+_encodeLink;

// if(GetQueryString('isApp') == 1 && GetQueryString('accountId') <= 0){
//     _loginUrl = 'ggj://redirect/typeCommon/{"type":6}'
// }

// function loginFun(){//判断是否登录,没登陆跳转登录页面
//     if(_loginType != 1){
//         window.location.href = _loginUrl
//     }
// }

// function loginLoad(){//判断是否登录返回true
//     if(_loginType == 1)
//         return true;
// }

// //获取某个cookie对应的cookie
// function getCookie(name){
//     var arr = document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
//     if(arr != null) return unescape(arr[2]);
//     return null;
// }

// function GetQueryString(name) {//获取url参数
//     var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)","i");
//     var r = window.location.search.substr(1).match(reg);
//     if (r!=null) return (r[2]); return null;
// }

;(function(win){

    if (typeof String.prototype.startsWith != 'function') {
        String.prototype.startsWith = function (prefix){
            return this.slice(0, prefix.length) === prefix;
        };
    }
    
    var ua = win.navigator.userAgent.toLowerCase(),
        WX_APP_ID = location.hostname.startsWith('test') ? 'wxda0ebb085665db33' : 'wx9af2b2d830d17368',
        wxCode = GetQueryString('code'),
        search = urlParamDel(location.search,'code'),
        currentUrl = location.origin + location.pathname + search,
        href = encodeURIComponent(currentUrl),
        redirect = 'redirect_url='+href,
        loginUrl = '/hp/login.html?'+redirect,
        loginType = getCookie("QQBSLG409292508");
    var isWx = ua.match(/MicroMessenger/i)=="micromessenger";
    // isWx = false;
    win._encodeLink = href;
    if(loginType!=1 && wxCode && isWx){//登录并获取accountid
        ajax({
            url:'/account/loginByCode',
            data:{code:wxCode},
            success:function(res){
                isRequested = true;
                res = JSON.parse(res);
                if(res.status=='1')
                    // location.replace(location.href+'&stamp='+new Date().getTime());
                    if(res.jumpPage=='1'){
                        window.location.href = '/hp/bound.html?'+redirect;  
                    }else if(res.jumpPage=='3'){
                        window.location.href = '/s2/PerfectData.html?'+redirect;
                    }else{
                        location.replace(currentUrl+'&stamp='+new Date().getTime());
                    }
            },
            fail:function(res){
                isRequested = true;
            }
        })
    }

    if(isWx){//微信环境
        loginUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' + WX_APP_ID + '&redirect_uri=' + href + '&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect';
    }else if(GetQueryString('isApp') == 1 && GetQueryString('accountId') <= 0){//app环境
        loginUrl = 'ggj://redirect/typeCommon/{"type":6}';
    }

    win.loginLoad = function(){//判断是否登录返回true
        return loginType == 1;
    }

    win.loginFun = function(){//判断是否登录,没登陆跳转登录页面
        if(loginType != 1){
            if(isWx && wxCode){

            }else{
                window.location.href = loginUrl;       
            }
        }
    }

    //删除当前链接中指定参数
    function urlParamDel(str, name){
        // var loca = window.location;
        // var baseUrl = loca.origin + loca.pathname + "?";
        var query = str.substr(1);
        if (query.indexOf(name)>-1) {
            var obj = {}
            var arr = query.split("&");
            for (var i = 0; i < arr.length; i++) {
                arr[i] = arr[i].split("=");
                obj[arr[i][0]] = arr[i][1];
            };
            delete obj[name];
            var url = JSON.stringify(obj).replace(/[\"\{\}]/g,"").replace(/\:/g,"=").replace(/\,/g,"&");
            return url && ('?'+url);
        }else{
            return str;
        };
    }

    //获取某个cookie对应的cookie
    function getCookie(name){
        var arr = document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
        if(arr != null) return unescape(arr[2]);
        return null;
    }

    function GetQueryString(name) {//获取url参数
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)","i");
        var r = window.location.search.substr(1).match(reg);
        if (r!=null) return (r[2]); return null;
    }

    //格式化参数
    function formatParams(data) {
        var arr = [];
        for (var name in data) {
            arr.push(encodeURIComponent(name) + "=" + encodeURIComponent(data[name]));
        }
        arr.push(("v=" + Math.random()).replace(".",""));
        return arr.join("&");
    }

    function ajax(options) {
        options = options || {};
        options.type = (options.type || "GET").toUpperCase();
        options.dataType = options.dataType || "json";
        var params = formatParams(options.data);

        //创建 - 非IE6 - 第一步
        if (window.XMLHttpRequest) {
            var xhr = new XMLHttpRequest();
        } else { //IE6及其以下版本浏览器
            var xhr = new ActiveXObject('Microsoft.XMLHTTP');
        }

        //接收 - 第三步
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                var status = xhr.status;
                if (status >= 200 && status < 300) {
                    options.success && options.success(xhr.responseText, xhr.responseXML);
                } else {
                    options.fail && options.fail(status);
                }
            }
        }

        //连接 和 发送 - 第二步
        if (options.type == "GET") {
            options.url = options.url.indexOf('?')>-1 ? options.url + "&" + params : options.url + "?" + params;
            xhr.open("GET", options.url, true);
            xhr.send(null);
        } else if (options.type == "POST") {
            xhr.open("POST", options.url, true);
            //设置表单提交时的内容类型
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.send(params);
        }
    }
})(window)