var reqShowCartCountUrl = yggcontextPath+'/spcart/showcartcount' ;
var reqmodifystatusurl =  yggcontextPath+"/spcart/getproductstatus/"+$product_id;
var rimer=null;
var flag=false;
 
var _favUrl = yggcontextPath+'/collect/add',
    _favCancelUrl = yggcontextPath+'/collect/cancel',
    _favBtn = $(".product-fav"),
    _favId = $product_id,
    _skuCartNum = 1,//默认商品数量
    _skuProductId = '';//选中的sku商品id


var _maskLoading = $(".mask-loading"),
    _window = $(window),
    _windowH = _window.height(),
    _goTop = $(".go-top");

$(function(){
    var $rec_acc = $('.recommend_name')
    if($rec_acc.length>0 && $rec_acc.text().length>=12){
        $rec_acc.text($rec_acc.text().substring(0,11)+'...');
    }
    $rec_acc.css('visibility','visible');
    /*访问统计*/
    var _tongJiUrl = yggcontextPath+'/vistStatis/getAccessStatis';
    $.post(_tongJiUrl);


    var _hotList = $(".product-hot"),
        _hotInfo = _hotList.find("ul"),
        _hotW = _hotList.width()/2.4;

    _hotInfo.width(_hotW);
//                console.log(_hotW);

    var hotSwiper = new Swiper('.product-hot',{
        slidesPerView : "auto",
        spaceBetween : 10,
        freeMode : true
    });

    var _curDate = new Date(),
        _time = _curDate.getTime(),
        _zeroTime = new Date(_curDate.toLocaleDateString()).getTime() - 1;

    var _countClick = parseInt($.cookie('countFav')),
        _timeCreate = $.cookie('countFavCreate');

    if(_timeCreate < _zeroTime ){
        $.cookie('countFav','',{ expires: -1,path: '/'});
    }
    window.easemobim = window.easemobim || {};
    easemobim.config = {
        tenantId: '20414',
        //orgName#appName
        appKey: 'globalscanner#globalscannerh5',
        //手机App绑定的IM号
        to: 'globalscanner00',
        emgroup:'美食买手',
        //是否隐藏小的悬浮按钮
        hide: true,
        //自动连接
        autoConnect: true,
        eventCollector:true,
        ticket:false,
        //下班后，不展示留言页面，不允许访客发送消息
        offDutyType: 'none'
    };
    if(window.location.hostname.startsWith('test')){
        easemobim.config['appKey'] = 'globalscanner#globalscannertest';
        easemobim.config['to'] = 'globalscannerTest';
    }

    $('.kefu-entry').click(function(){
        if(!loginLoad()){//判断是否登录
            loginFun()
            return false;
        }
        var _e = window.event;
        $.ajax({
            url:yggcontextPath+'/huanxin/user',
            type:'post',
            success:function(data){
                if(data.username){
                    window.event = _e;
                    window.easemobim.config = {
                        tenantId: data.tenantId,
                        //orgName#appName
                        appKey: data.appKey,
                        //手机App绑定的IM号
                        to: data.to,
                        //是否隐藏小的悬浮按钮
                        hide: true,
                        //自动连接
                        autoConnect: true,
                        eventCollector:true,
                        ticket:false,
                        //下班后，不展示留言页面，不允许访客发送消息
                        offDutyType: 'none'
                    }

                    window.easemobim.config.user={
                        //指定用户名，集成时必填
                        username: data.username,
                        //password验证方式
                        password: data.password
                    }
                    window.easemobim.config.visitor = {
                        userNickname: data.username,
                        trueName: data.username
                    }
                    window.easemobim.bind({
                        tenantId: '20414',
                        ticket: false,
                        offDutyType: 'none'
                    });
                }else if(data.status == '4'){
                    loginFun();
                    return false;
                }
            }
        })

    })

    _window.scroll(function(){
        if(_window.scrollTop() >= _windowH/2){
            _goTop.fadeIn();
            //console.log(_window.scrollTop(),_windowH );
        }else{
            _goTop.fadeOut();
        }
    });
    //吸顶
    _goTop.click(function(){
        $("body,html").animate({"scrollTop":0},500);
        return false;
    });

    //收藏
    _favBtn.click(function(){
        if(!loginLoad()){//判断是否登录
            loginFun()
            return false;
        }

        if($(this).hasClass("on")){

            $.ajax({
                url:_favCancelUrl,
                type:'post',
                data:{
                    type:1,
                    collectId:_favId
                },
                success:function(data){
                    if(data.status == 1){
                        showTipMsg('取消收藏');
                        _favBtn.removeClass("on").text("收藏");
                        $('#rebegin').removeClass("on").text("抢先收藏");
                    }
                }
            })
        }else{
            $.ajax({
                url:_favUrl,
                type:'post',
                data:{
                    type:1,
                    collectId:_favId
                },
                success:function(data){
                    if(data.status == 1){
//                                    console.log('收藏成功');
                        _favBtn.addClass("on").text("已收藏");
                        $('#rebegin').addClass("on").text("取消收藏");
//                                  $(".fav-tan").show();

                        if(_favStyle == 3){
                            _countClick += 1;
                            $.cookie('countFav',_countClick,{ expires:2,path: '/'})
                            if(_countClick == 1 || _countClick == 5){
                                $(".fav-tan").show();
                            }else{
                                showTipMsg('收藏成功');
                            }
                        }else{
                            showTipMsg('收藏成功');
                        }

                    }
                }
            })
        }
    })


    $(".fav-tan,.tan-close").click(function(){
        $(".fav-tan").hide();
    })

    $(".yaoqing-close").click(function () {
        $(".yaoqing-tan").hide();
    })

    $('#rebegin').click(function(){
        if(!loginLoad()){//判断是否登录
            loginFun()
            return false;
        }

        if(isSkuInfo){
            _favId = _skuProductId;
        }
        if($(this).hasClass("on")){
            $.ajax({
                url:_favCancelUrl,
                type:'post',
                data:{
                    type:1,
                    collectId:_favId
                },
                success:function(data){
                    if(data.status == 1){
                        showTipMsg('取消收藏');
                        _favBtn.removeClass("on").text("收藏");
                        $('#rebegin').removeClass("on").text("抢先收藏");
                    }
                }
            })
        }else{
            $.ajax({
                url:_favUrl,
                type:'post',
                data:{
                    type:1,
                    collectId:_favId
                },
                success:function(data){
                    if(data.status == 1){
                        console.log('收藏成功');
                        _favBtn.addClass("on").text("已收藏");
                        $('#rebegin').addClass("on").text("取消收藏");

                        if(_favStyle == 3){
                            _countClick += 1;
                            $.cookie('countFav',_countClick,{ expires:2,path: '/'})
                            if(_countClick == 1 || _countClick == 5){
                                $(".fav-tan").show();
                            }else{
                                showTipMsg('收藏成功');
                            }
                        }else{
                            showTipMsg('收藏成功');
                        }
                    }
                }
            })
        }
    });

});

//链接跳转
function turnLink(url){
    window.location.href = url;
}

$(function(){

    refUlr();

    $("#addbegin").click(function(){
        var accountType = $("#accountType").val(); //0 是普通用户 1 初级代理 2 高级代理
        if(!loginLoad()){//判断是否登录
            loginFun()
            return false;
        }
        //accountType = "0";
        var _mbType = $(this).data('member'),
            _mbBox = $('.member-dialog'),
            _mbCancle = $('.dialog-close'),
            _maskFull = $('.mask-full'),
            _memberDialogBox = $(".member-dialog-box"),
            _mbTure = $isMb,
            _skuType = $(this).data("sku");

        if(accountType === "0"){
            _mbBox.show();
            _memberDialogBox.show();
            _mbCancle.click(function(){
                _mbBox.hide();
                _memberDialogBox.hide();
            });
            return false;
        }
        if(_skuType == 1) return false;

        /* if(_mbType > 0 && _mbTure == 0){//会员商品，非会员弹出对话框

             _mbBox.show();
             _maskFull.show();

             _mbCancle.click(function(){
                 _mbBox.hide();
                 _maskFull.hide();
             })
             return false;
         }*/

        var productid = $('#form1 input[name=productid]').val();
        var productcount = 1;
        if(isSkuInfo){
            productid = _skuProductId;
            productcount = _skuCartNum;
        }

        _maskLoading.show();
//                   return false;


        var data = "productid="+productid+"&productcount="+productcount;
        editshoppingcart(yggcontextPath+"/spcart/editscbsp?gpm="+$gpm,data);

        /////更新商品的状态//////
        if(isSkuInfo){
            var requrl = yggcontextPath+"/spcart/getproductstatus/"+ productid;
        }else{
            var requrl = yggcontextPath+"/spcart/getproductstatus/"+$product_id;
        }

        $.ajax({
            type:'POST',
            url: requrl ,
            data:'',
            dataType: 'json' ,
            success: function(msg){

                var productStatus = msg.productStatus ;
                showProductStatus(productStatus);
            },
            error:function(err){
            }
        });

    });

    //秒杀商品点击立即购买
    $("#buyNow").click(function(){
        var _skuBox = $(".product-sku");
        var _maskFull = $(".mask-full");
        var _body = $("html,body");
        //判断是否有多sku
        if(isSkuInfo){
            _skuBox.show();
            _maskFull.show();
            _body.css({height:'100%',overflow:'hidden'})
        }else{
            if(!loginLoad()){//判断是否登录
                loginFun()
                return false;
            }
            buyNow()
        }
    })

    //秒杀品，点击sku确定secComfirm
    $("#secComfirm").click(function(){
        if(!loginLoad()){//判断是否登录
            loginFun()
            return false;
        }
        buyNow()
    })

    function buyNow(){
        //秒杀品判断是否能立即购买
        var securl = yggcontextPath+"/order/confirmRN";
        var pid;
        if(isSkuInfo){
            //pid = $('#form1 input[name=productid]').val();
            pid = $(".sku-first-list").data('id')
            console.log(pid,'pid')
        }else{
            pid = $product_id
        }
        $.ajax({
            type:'POST',
            url: securl ,
            data:{productId:pid},
            dataType: 'json' ,
            success: function(msg){
                console.log(msg,'msg')
                if(msg.status == '1'){
                    window.location.href= yggcontextPath + "/order/confirm/1?gpm=0&productId="+ pid +"&addressId=-1&secKill=1";
                }else{
                    //window.location.reload()
                    showTipMsg(msg.errorMessage)
                    setTimeout(function () {
                        window.location.href = $(".product-sku").data('url') + "?saleUnitId=" + pid;
                    },2000)
                }
            },
            error:function(err){
            }
        })
    }

    $("#nextbegin").click(function(){
        showTipMsg("此商品有人拍下未付款，还有机会购买，试着刷新页面看看吧～");
    });

    //临时活动入口展示
//              var _activityTime = new Date(),
//                  _activityDate = _activityTime.getDate(),
//                  _activityHour = _activityTime.getHours();
//
//              if(_activityDate == 9){
//                  if(_activityHour >= 20){
//                      $(".activity-link").show();
//                  }
//              }
//              if( 9 <_activityDate && _activityDate <12){
//                    $(".activity-link").show();
//              }

    //已抢完提示
    var _endTip = $(".product-end-tip"),
        _tipListProduct = $(".product-end-hot");

    _endTip.css({bottom:(_tipListProduct.outerHeight() + 50)});

    _endTip.click(function(){
        var _this = $(this);
        if(_this.hasClass("on")){
            $(this).removeClass("on").css({bottom:50});
            _tipListProduct.removeClass("on").find("p").show();
        }else{
            $(this).addClass("on").css({bottom:(_tipListProduct.height() + 50)});
            _tipListProduct.addClass("on").find("p").hide();
        }

    })

}) ;

$(function(){
    var _replaceText = $('.replace-str');
    _replaceText.each(function(){
        var _this = $(this);
        replaceStr(_this);
    });

    if(loginLoad()){
        $.getCartCount(yggcontextPath+'/spcart/showcartcount','productid='+$product_id); /*查询购物车的数量*/
    }
    //// 查多少人购买，库存，倒计时 ////
    var  caId = $("#caId").val() ;
    var  requrl =  yggcontextPath+"/goods/getSaleUnitInfo/"+$product_id ;
    //倒计时请求
    $.ajax({
        type:'POST',
        url: requrl ,
        data:'',
        dataType: 'json' ,
        success: function(msg){
            var second= msg.second ;
            var sellCount = msg.sellCount ;
            var stockCount =msg.stockCount ;
            var productStatus = msg.productStatus ;
            var isSecKill = msg.isSecKill ;

            if(isSecKill && isSecKill == '1'){
                // $('#cart1').hide();
                // $('#cart2').show();
                $('#sku-cart').hide();
                // $('#sku-btn-box1').hide();
                // $('#sku-btn-box2').show();
                $('#addbegin').hide();

                if(isSkuInfo){
                    $('#buyNow').show()
                    $('#addCart').hide()
                    $('.buy-sku-btn').addClass('buyitem-sec')
                    //$('#sku-btn-box1').attr('isSecKill','1')
                    // if(productStatus == '1'){
                    //     $('#secComfirm').show();
                    // }else{
                    //     $('#secComfirm').hide();
                    // }
                }else{
                    $('.buy-sku-btn').removeClass('buyitem-sec')
                }
                // if(stockCount < 1){
                //     $('#buyNow').hide();
                //     $('#secEndbegine').show();
                // }else{
                //     $('#buyNow').show();
                //     $('#secEndbegine').hide();
                // }
            }else{
                // $('#cart1').show();
                // $('#cart2').hide();
                $('#sku-cart').show();
                // $('#sku-btn-box1').show();
                // $('#sku-btn-box2').hide();
                // $('#addbegin').show();
            }

            $('#psellCount').html(sellCount);
            $('#stockCount').html(stockCount);
            showClockTime(productStatus,second,isSecKill);
        },
        error:function(err){
        }
    });
    if(is_skuInfo){
        $('.buyitem').hide();
    }


    function showClockTime(productStatus,second,isSecKill)
    {
        /* count down */
        var stime='';
        var etime='';
        if(productStatus == '1' )
        {
            etime=second ;
        }else if(productStatus == '2')
        {
            etime=second ;
        }else if(productStatus == '3')
        {
            stime=second ;
        }else if(productStatus == '4')
        {
            etime=second ;
        }

        if(stime!='' || stime>0){
            //$('#rebegin').show();
            // $('.pgoods_time').addClass('off');
            $('.pgoods_time1').show();
            var sid="#clockbox1";
            var timer = setInterval(function(){
                stime--;
                countDownA(stime,sid,etime);
            },980);
            countDownA(stime,sid,etime);
        }else{
            if(etime!='' || etime>0){
                //$('#addbegin').show();
                //$('.pgoods_time1').addClass('off');
                $('.pgoods_time').show();
                var sid="#clockbox";
                var timer = setInterval(function(){
                    etime--;
                    countDown(etime,sid);
                },980);
                countDown(etime,sid);
            }else{
                //$('#endbegin').show();
                //$('.pgoods_time1').addClass('off');
                //$('.pgoods_time').addClass('off');
                $('.pgoods_time1').hide();
                $('.pgoods_time').hide();
            }
        }

        showProductStatus(productStatus,isSecKill);

    }

}) ;

function  showProductStatus(ps,isSecKill)
{
//           $('.buyitem').hide();
    if(ps == '1' )
    {
        if(isSecKill && isSecKill=='1'){
            $('#buyNow').show()
            $('#addbegin').hide();
            $('#buy-bottom-info1').hide()
            $('#buy-bottom-info2').show()
        }else{
            $('#addbegin').show();
            $('#buyNow').hide()
            $('#buy-bottom-info1').show()
            $('#buy-bottom-info2').hide()
        }
    }else if(ps == '2')
    {
        $('#buyNow').hide()
        //$('#secComfirm').hide()
        if(isSecKill && isSecKill=='1'){
            $('#cart1').find('#nextbegin').addClass('buyitem-sec').show();
            //$('#nextbegin').show();
            $('#buy-bottom-info1').hide()
            $('#buy-bottom-info2').show()
        }else{
            $('#nextbegin').show();
            $('#buy-bottom-info1').show()
            $('#buy-bottom-info2').hide()
        }
    }else if(ps == '3')
    {
        $('#buyNow').hide()
        $('#secComfirm').hide()
        if(isSecKill && isSecKill=='1'){
            $('#cart1').find('#rebegin').addClass('buyitem-sec').show();
            $('#buy-bottom-info1').hide()
            $('#buy-bottom-info2').show()
        }else{
            $('#rebegin').show();
            $('#buy-bottom-info1').show()
            $('#buy-bottom-info2').hide()
        }
    }else if(ps == '4')
    {
        $('#buyNow').hide()
        $('#secComfirm').hide()
        if(isSecKill && isSecKill=='1'){
            $('#cart1').find('#endbegin').addClass('buyitem-sec').show();
            $('#buy-bottom-info1').hide()
            $('#buy-bottom-info2').show()
        }else{
            $('#endbegin').show();
            $('#buy-bottom-info1').show()
            $('#buy-bottom-info2').hide()
        }
    }
}

//去掉/
function replaceStr(str){
    var _this = $(str),

        _str = _this.text(),

        _replace = '';
    if(_str.length == '') return false;

    var reg=/\\/g;

    _replace = _str.replace(reg,'');

    _this.text(_replace);
}