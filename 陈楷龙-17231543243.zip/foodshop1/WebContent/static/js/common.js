/**
 * Created by linhai on 2017/7/25.
 */
/*
 *获取当前访问域名，
 * name(域名后的项目路径名，根据自己的环境配置传入对应值)，列：
 */
function requestHeader(name){
    var _name = name,
        _link = window.location.href,
        _headerStr = '';

    if(!_name){
        _name = '';
    }
    _headerStr = location.protocol+'//'+ location.host
    return _headerStr;
}

//url里面拿需要的参数
function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)","i");
    var r = window.location.search.substr(1).match(reg);
    if (r!=null) return (r[2]); return null;
}

// 验证手机号
function isPhoneNo(phone) {
    var pattern = /^1[3-9]\d{9}$/;
    return pattern.test(phone);
}

//提示消息
function showTipMsg(msg)
{
    /* 给出一个浮层弹出框,显示出errorMsg,2秒消失!*/
    $('.protips').html(msg).show();
    setTimeout(function(){
        $('.protips').hide();
    },2000);
}

//链接跳转
function turnLink(url){
    window.location.href = url;
}

//监测app跳转h5页面referrer,处理返回
function appBackFun(name){
    var _ref = document.referrer,
        _turnBack = $(name);

    if(_ref != ''){
        _turnBack.click(function(){
            window.history.back();
        })
    }else{
        _turnBack.click(function(){
            turnLink('ggj://redirect');
        })
    }
}

/*
 * 通过app链接获得微信验签
 *type=1 会拼上访问链接后面的参数
 */
function appLinkStr(url,type){
    var _refLink = window.location.href,
        _refArr = _refLink.split('?'),
        _refStr = _refArr[1],
        _isApp = _refLink.indexOf('isApp'),
        _reqUrl = url,
        _reqSub = _reqUrl.split('?'),
        _type = type;

    if(_isApp > -1 || (type == 1 && _refStr)){
        if(_reqSub.length > 1 && _reqSub[1].length > 0){
            _reqUrl = url + '&'+_refStr
        }else{
            _reqUrl = url + '?'+_refStr
        }
    }
    return _reqUrl;
}

//处理安卓机软键盘遮挡输入框问题
function androidKeyFun(){
    if(/Android [4-6]/.test(navigator.appVersion)) {
        window.addEventListener("resize", function() {
            if(document.activeElement.tagName=="INPUT" || document.activeElement.tagName=="TEXTAREA") {
                window.setTimeout(function() {
                    document.activeElement.scrollIntoViewIfNeeded();
                },0);
            }
        })
    }
}

String.prototype.replaceAll = function(s1,s2){
    return this.replace(new RegExp(s1,"gm"),s2);
}

function wxShouQuan(type){
    if(type == 4){//处理微信调用接口缓存授权问题
        var _link = window.location.href;

        if(_link.indexOf('?') > -1){
            window.location.href = _link + '&cache='+Math.round(Math.random()*100);
        }else{
            window.location.href = _link + '?cache='+Math.round(Math.random()*100);
        }
    }
}
//返給后台url參數验签
function linkTidFun(){
    var _ref = window.location.href,
        _refNum = _ref.indexOf('?'),
        _refTid = '';

    if(_refNum > -1){
        _refNum += 1;
        _refTid = _ref.substring(_refNum,_ref.length);
    }

    return _refTid;
}

//替换json中\n
function replaceBr(str){
    var jsonStr = JSON.stringify(str).replace(/\\n/gi,"<br>")

    if(typeof(str) != 'string'){
        jsonStr = JSON.parse(jsonStr)
    }
    return jsonStr
}

function tongjiFun() {
    var _tjDiv = document.createElement("div"),
        _tjHtml = '<script src="https://s22.cnzz.com/z_stat.php?id=1264316314&web_id=1264316314" ><\/script>',
        _tjAppHtml = '<script src="https://s22.cnzz.com/z_stat.php?id=1264316269&web_id=1264316269"><\/script>';

    _tjDiv.style.display = "none"

    if(window.location.href.indexOf("isApp=1") > -1){
        _tjDiv.innerHTML = _tjAppHtml
    }else{
        _tjDiv.innerHTML = _tjHtml
    }
    document.body.appendChild(_tjDiv)
}