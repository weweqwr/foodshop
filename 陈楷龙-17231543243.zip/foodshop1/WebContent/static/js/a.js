    window.onload = function(){
        $('.login-tel').focus();
    }

    var _loginUrl = appLinkStr('/account/loginAjax',1),
        _sendUrl = appLinkStr('/user/sendBoundCode'),
        _stateUrl = appLinkStr('/account/logadlist'),
        _linkStr = GetQueryString('redirect_url'),
        _decodeLink = decodeURIComponent(_linkStr),
        _pinJUrl = '',
        _cityLetter = ['A','B','C','D','E','F','G','H','J','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

    if(_linkStr && _linkStr != ''){
        _pinJUrl = "redirect_url=" + _linkStr
    }

    var loginV = new Vue({
        el:'.login-box',
        data:{
            hostList:[],
            stateList:[],
            telForm:false,
            timeout:false,
            loginActive:false,
            tel:'',
            code:'',
            isRequest:false,
            isTip:false,
            isShow:false,
            codeTxt:'��ȡ��֤��',
            tipTxt:'',
            sendType:false,
            accountId:GetQueryString('accountId') ? GetQueryString('accountId') :'',
            isState:0,
            stateNum:'86',
            showState:false,
            showVoice:false,
            voiceType:false,
            stateArr:[],
            voiceTip:false,
            voiceTimer:0,
            voiceType:false
        },
        methods:{
            getState:function(){
                var _this = this
                $.ajax({
                    url:_stateUrl,
                    type:'post',
                    data:'',
                    success:function(data){
                        if(data.status == 1){
                            _this.isState = data.isHideSea
                            _this.hostList = data.hotAddressList
                            _this.stateList = data.allAddressList

                            _this.stateArr = _this.cityInfoData(_this.stateList,_cityLetter)
                        }
                    }
                })
            },
            inputTel:function(){
                 var _this = this;
                 $('li').first().addClass('active-border');
                 $('li').eq(1).removeClass('active-border');
                 $('.login-tel').bind("input propertychange",function(){
                    if((_this.tel !== '' && isPhoneNo(_this.tel) && _this.tel.toString().length == 11) || _this.stateNum != '86'){
                        _this.telForm = true;
                    }else{
                        _this.telForm = false;
                    }
                 })
            },
            inputYzm:function(){
                var _this = this;
                $('li').first().removeClass('active-border');
                $('li').eq(1).addClass('active-border');
                $('.yzm-txt').bind("input propertychange",function(){
                    if( _this.code.length == 4){
                        _this.loginActive = true;
                    }
                });
            },
            saveBtn:function(){
                var _this = this;
                if(_this.tel == ''){
                    _this.showTip('����д�ֻ�����');
                    return false;
                }
                if(!isPhoneNo(_this.tel) && _this.stateNum == '86'){
                    _this.showTip('����д��ȷ���ֻ���');
                    return false;
                }
                if(_this.code == ''){
                    _this.showTip('��֤�벻��Ϊ��');
                    return false;
                }
                _this.telForm = true;
                if(_this.code.length <= 0 || _this.code.length > 4){
                    _this.showTip("��������ȷ����֤��");
                    return false;
                }

                if(!_this.isRequest){
                    _this.isRequest = true;

                    $.ajax({
                        url:_loginUrl,
                        type:'post',
                        data:{
                            name:_this.tel,
                            code:_this.code,
                            addressCode:_this.stateNum
                        },
                        success:function(data){;
                            if(data.status == 1){
                                if(data.jumpPage && data.jumpPage == 3){
                                     window.location.href='/s2/PerfectData.html?'+_pinJUrl;
                                }else if(data.jumpPage && data.jumpPage == 1){
                                    window.location.href="boundMesg.html?"+linkTidFun()+"&name="+_this.tel+'&'+_pinJUrl;
                                 }else{
                                    if(!_linkStr || _linkStr == ''){
                                        _decodeLink = 'home.html'
                                    }
                                    window.location.href = _decodeLink
                                 }
                            }else{
                                if(data.msg){
                                    _this.showTip(data.msg)
                                }else{
                                    _this.showTip('����������Ժ�����~')
                                }
                            }
                            _this.isRequest = false;
                        },
                        error:function(data){
                            _this.isRequest = false;
                            console.log(data);
                        }
                    })
                }

            },
            sendCode:function(type){//type 1 ���ţ�2����
                var _this = this,
                    _codeType = type

                if(_this.tel == ''){
                    _this.showTip('����д�ֻ�����');
                    return false;
                }

                if(!isPhoneNo(_this.tel) && _this.stateNum == '86'){//�����ֻ����ж�
                    _this.showTip('����д��ȷ���ֻ���');
                    return false;
                }

                if(_this.tel.length > 15){//�����ֻ���ֻ�жϳ���
                    _this.showTip('����д��ȷ���ֻ���');
                    return false;
                }

                if(_codeType == 1){
                    if(_this.sendType)  return false
                    _this.sendType = true
                    _this.timeCount()

                    if(_this.stateNum == '86'){
                        var _vTime = 15
                        var _vDTimer = setInterval(function(){
                            _vTime == _vTime--

                            if(_vTime <= 1 && !_this.voiceType){
                                clearInterval(_vDTimer)
                                _this.showVoice = true
                            }
                        },1000)
                    }

                }else{
                    if(_this.voiceType){
                        _this.showTip('��Ⱥ�'+_this.voiceTimer+'s������')
                        return false
                    }else{
                        _this.voiceType = true
                        _this.timeCountV()
                    }
                }
                
                $.ajax({
                    url:_sendUrl,
                    type:'post',
                    data:{
                        mobileNumber:_this.tel,
                        addressCode:_this.stateNum,
                        channelType:_codeType
                    },
                    success:function(data){
                        console.log(data);
                     
                        if(data.status == 1){
                            if(_codeType == 2){
                                _this.voiceTip = true
                            }
                        }else{
                            _this.showTip(data.msg);
                        }

                    },
                    error:function(data){
                        console.log(data);
                    }
                })

            },
            showTip:function(msg){
                var _this = this;

                _this.isTip = true
                _this.tipTxt = msg
                setTimeout(function(){
                    _this.isTip = false
                },2000)
            },
            clear:function(type){
                var _this = this;
                if(type == 1){
                    _this.tel = '';
                    _this.telForm = false;
                    _this.loginActive = false;
                }
                if(type == 2){
                    _this.code = '';
                    _this.loginActive = false;
                }
            },
            timeCount:function(){
                var _timer = 59,
                    _this = this;

                _this.telForm = false
                _this.codeTxt = _timer + 's'
                var timerCount = setInterval(function(){
                    
                    if(_timer <= 0){
                        clearInterval(timerCount)

                        _this.sendType = false
                        _this.codeTxt = "�ط�"
                        _this.telForm = true;
                    }else{
                        _timer--;
                        _this.codeTxt = _timer + 's'
                    }
                },1000)
            },
            timeCountV:function(){
                var _timer = 59,
                    _this = this;

                var vTimerCount = setInterval(function(){
                    if(_timer <= 0){
                        clearInterval(vTimerCount)
                        _this.voiceType = false
                    }else{
                        _timer--;
                        _this.voiceTimer = _timer
                    }
                },1000)
            },
            stateFun:function(){
                var _this = this

                _this.showState = true
                window.location.hash = '#stateList'
                _this.$nextTick(function(){
                    _this.asideMove()
                })
            },
            stateChoose:function(str){
                var _this = this

                if(str != '86'){
                    _this.showVoice = false
                    _this.voiceType = true
                }else{
                    _this.voiceType = false
                }
                _this.stateNum = str
                window.location.hash = ''
            },
            getItem:function(letter,list){//ת���Աȴ�������ĸ���з���
                var arr = [],
                    _this = this

                list.map(function(item){
                    var name = makePy(item.addressName)[0];

                    if(name == letter){
                        var _item = {
                            name:item.addressName,
                            code:item.addressCode
                        }
                        arr.push(_item);
                    }
                })
                return arr;
            },
            cityInfoData:function(list,letter){//�ѷ���õ����ݷ�װΪ���ö���
                var arr = [],
                    _this = this

                letter.map(function (item) {
                    var resArr = _this.getItem(item,list);
                    if(resArr.length > 0){
                        arr.push({
                            letter:item,
                            list:resArr
                        })
                    }
                })
                return arr;
            },
            asideMove:function(){
                var _listBox = $(".login-state"),
                    _asideBox = $(".aside-shortcut"),
                    _width = _asideBox.find("a").width(),
                    _height = _asideBox.find("a").height()

                _asideBox.on('touchmove',function(e){
                    e.preventDefault();

                    var _touch = e.touches[0],
                        _touchArea = {"x": _touch.pageX, "y": _touch.pageY},
                        _touchX = _touchArea.x,
                        _touchY = _touchArea.y;

                    $(this).find("a").each(function (i, item) {
                        var _offset = $(item).offset(),
                            _left = _offset.left,
                            _top = _offset.top,
                            _scrolls = _listBox.scrollTop()

                        if (_touchX > _left && _touchX < (_left + _width) && _touchY > _top && _touchY < (_top + _height)) {
                            var _id = $(this).data("id")

                            if($('#'+_id).length > 0){
                                var _topH = $('#'+_id).offset().top

                                _listBox.scrollTop(_topH + _scrolls)
                            }
                        }
                    });
                })
            }
        },
        watch:{
            tel:function(val,oldVal){
                var _telLen = val.toString()

                if(_telLen.length > 11 && this.stateNum == '86'){
                    this.tel = _telLen.substring(0,11);
                }

                if(_telLen.length > 15){
                    this.tel = _telLen.substring(0,15);
                }
            },
            code:function(val,oldVal){
                var _codeLen = val.toString()

                if(_codeLen.length > 4){
                    this.code = _codeLen.substring(0,4);
                }
            },
            stateNum:function(val){
                var _telLen = this.tel.toString()

                if(val != '86' && _telLen.length > 1){
                    this.telForm = true
                }

                if(_telLen.length < 11 && val == '86'){
                    this.tel = _telLen.substring(0,11);
                    this.telForm = false
                }
            }
        },
        mounted:function(){
            var _this = this;

            window.onhashchange = function(){
                var _hash = window.location.hash;

                if(_hash == ''){
                    _this.showState = false
                }else{
                    _this.showState = true
                }
            }
        },
        created:function(){
            this.getState()
        }
    })
