!function(root){
    function IsPC() {
        var userAgentInfo = navigator.userAgent;
        var Agents = ["Android", "iPhone",
                    "SymbianOS", "Windows Phone",
                    "iPad", "iPod","NokiaN9"];
        var flag = true;
        for (var v = 0; v < Agents.length; v++) {
            if (userAgentInfo.indexOf(Agents[v]) > 0) {
                flag = false;
                break;
            }
        }
        return flag;
    }
    var ua = navigator.userAgent.toLowerCase();
    // if(ua.indexOf('globalscanner') == -1 && !IsPC()){
    //     var head = document.getElementsByTagName('head')[0];
    //     var link = document.createElement('link');
    //     link.href = root.location.origin + '/pages/css/dl_banner.css';
    //     link.rel = 'stylesheet';
    //     link.type = 'text/css';
    //     head.appendChild(link);
    //
    //     var _imgsrc = root.location.origin + '/hp/images/logo.png'
    //     var _banner = '<div class="dl_view"><img src="'+_imgsrc+'"><span><em>美食买手</em><br><em>一起买更划算</em></span><a href="http://a.app.qq.com/o/simple.jsp?pkgname=com.globalagency">打开APP</a></div>'
    //     document.body.insertAdjacentHTML('afterBegin',_banner);
    // }
    
}(this);
