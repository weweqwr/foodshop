package com.foodshop.pojo;

public class User {
	private Integer UserId;
	private Integer GoodsId;
	private Integer ImageId;
	private String UserName;
	private String PassWord;
	private String GoodsName;
	private float price;
	private boolean Indexlb;
	private String Introduct;
	private String Address;
	private Integer InfoShow;
	private String ProducingArea;
	private String Brand;
	private String ShelfLife;
	private String UseMethod;
	private String Specifications;
	private String EatMethod;
	private String ServiceInfo;
	private Integer IndexnShow;
	public Integer CarId;
	private Integer Sum;
	private String UserHead;
	private String UserMc;
	private Integer clear;
	private Integer OrderId;
	private Integer Pay;
	private Integer SumPrice;
	private Integer GroupBuyId;
	private Integer flag;
	private Integer flag1;
	private Integer LuckPrice;
	private Integer ShuLiang;
	private Integer LuckId;
	private String LuckAddress;
	private String LuckName;
	private String usen;
	public Integer getUserId() {
		return UserId;
	}
	public void setUserId(Integer userId) {
		UserId = userId;
	}
	public Integer getGoodsId() {
		return GoodsId;
	}
	public void setGoodsId(Integer goodsId) {
		GoodsId = goodsId;
	}
	public Integer getImageId() {
		return ImageId;
	}
	public void setImageId(Integer imageId) {
		ImageId = imageId;
	}
	public String getGoodsName() {
		return GoodsName;
	}
	public void setGoodsName(String goodsName) {
		GoodsName = goodsName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public boolean isIndexlb() {
		return Indexlb;
	}
	public void setIndexlb(boolean indexlb) {
		Indexlb = indexlb;
	}
	public String getIntroduct() {
		return Introduct;
	}
	public void setIntroduct(String introduct) {
		Introduct = introduct;
	}
	
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassWord() {
		return PassWord;
	}
	public void setPassWord(String passWord) {
		PassWord = passWord;
	}
	public Integer getInfoShow() {
		return InfoShow;
	}
	public void setInfoShow(Integer infoShow) {
		InfoShow = infoShow;
	}
	public String getProducingArea() {
		return ProducingArea;
	}
	public void setProducingArea(String producingArea) {
		ProducingArea = producingArea;
	}
	public String getBrand() {
		return Brand;
	}
	public void setBrand(String brand) {
		Brand = brand;
	}
	public String getShelfLife() {
		return ShelfLife;
	}
	public void setShelfLife(String shelfLife) {
		ShelfLife = shelfLife;
	}
	public String getUseMethod() {
		return UseMethod;
	}
	public void setUseMethod(String useMethod) {
		UseMethod = useMethod;
	}
	public String getSpecifications() {
		return Specifications;
	}
	public void setSpecifications(String specifications) {
		Specifications = specifications;
	}
	public String getEatMethod() {
		return EatMethod;
	}
	public void setEatMethod(String eatMethod) {
		EatMethod = eatMethod;
	}
	public String getServiceInfo() {
		return ServiceInfo;
	}
	public void setServiceInfo(String serviceInfo) {
		ServiceInfo = serviceInfo;
	}
	public Integer getIndexnShow() {
		return IndexnShow;
	}
	public void setIndexnShow(Integer indexnShow) {
		IndexnShow = indexnShow;
	}
	public Integer getCarId() {
		return CarId;
	}
	public void setCarId(Integer carId) {
		CarId = carId;
	}
	public Integer getSum() {
		return Sum;
	}
	public void setSum(Integer sum) {
		Sum = sum;
	}
	public String getUserHead() {
		return UserHead;
	}
	public void setUserHead(String userHead) {
		UserHead = userHead;
	}
	public String getUserMc() {
		return UserMc;
	}
	public void setUserMc(String userMc) {
		UserMc = userMc;
	}
	public Integer getClear() {
		return clear;
	}
	public void setClear(Integer clear) {
		this.clear = clear;
	}
	public Integer getOrderId() {
		return OrderId;
	}
	public void setOrderId(Integer orderId) {
		OrderId = orderId;
	}
	public Integer getPay() {
		return Pay;
	}
	public void setPay(Integer pay) {
		Pay = pay;
	}
	public Integer getSumPrice() {
		return SumPrice;
	}
	public void setSumPrice(Integer sumPrice) {
		SumPrice = sumPrice;
	}
	public Integer getGroupBuyId() {
		return GroupBuyId;
	}
	public void setGroupBuyId(Integer groupBuyId) {
		GroupBuyId = groupBuyId;
	}
	public Integer getFlag() {
		return flag;
	}
	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	public Integer getFlag1() {
		return flag1;
	}
	public void setFlag1(Integer flag1) {
		this.flag1 = flag1;
	}
	public Integer getLuckPrice() {
		return LuckPrice;
	}
	public void setLuckPrice(Integer luckPrice) {
		LuckPrice = luckPrice;
	}
	public Integer getShuLiang() {
		return ShuLiang;
	}
	public void setShuLiang(Integer shuLiang) {
		ShuLiang = shuLiang;
	}
	public Integer getLuckId() {
		return LuckId;
	}
	public void setLuckId(Integer luckId) {
		LuckId = luckId;
	}
	public String getLuckAddress() {
		return LuckAddress;
	}
	public void setLuckAddress(String luckAddress) {
		LuckAddress = luckAddress;
	}
	public String getLuckName() {
		return LuckName;
	}
	public void setLuckName(String luckName) {
		LuckName = luckName;
	}
	public String getUsen() {
		return usen;
	}
	public void setUsen(String use) {
		this.usen = use;
	}
	
	
}
