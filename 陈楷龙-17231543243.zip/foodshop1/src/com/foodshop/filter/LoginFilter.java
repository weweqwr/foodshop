package com.foodshop.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.foodshop.pojo.User;


@WebFilter(urlPatterns= {"/showOrder","/showCar","/doCar","/doMy","/doIndex","/Home/views/sindex.jsp","/Home/views/my.jsp","/Home/views/order.jsp","/Home/views/car.jsp","/Home/views/information.jsp"})

public class LoginFilter implements Filter {
    public void destroy() {
    }
 
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        //chain.doFilter(req, resp);
        HttpServletRequest request = (HttpServletRequest)req;
        HttpServletResponse response = (HttpServletResponse)resp;
        request.setCharacterEncoding("UTF-8");
//        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        PrintWriter out = response.getWriter();
        String user = (String) session.getAttribute("UserName");
        if(user != null){     	
            chain.doFilter(request,response);
        } else{
            out.println("�㻹û��¼�����ܽ������ҳ��");
            
            response.setHeader("refresh","3;/foodshop1/Login");
    
        }
    }
 
    public void init(FilterConfig config) throws ServletException {
 
    }
 
}

