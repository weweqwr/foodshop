package com.foodshop.service.user;

import java.util.ArrayList;
import java.util.List;

import com.foodshop.pojo.User;

public class Sub {
	public List<String> sub(String a) {
		String c="";
		List<String> list=new ArrayList();
		for(int i=0;i<a.length();i++) {
			String b=String.valueOf(a.charAt(i));
			if(b.equals(",")) {
				list.add(c);
				c="";
			}else {
				c+=String.valueOf(a.charAt(i));
			}
		}
		return list;
	}
}
