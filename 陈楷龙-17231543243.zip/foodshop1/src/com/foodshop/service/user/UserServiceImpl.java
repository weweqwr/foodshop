package com.foodshop.service.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foodshop.dao.user.UserMapper;
import com.foodshop.pojo.User;

@Service("userService")
public class UserServiceImpl implements UserService {
   @Autowired//��@Resource
	private UserMapper userMapper;
   
    public List<User> findUser(User user) throws Exception  {
		try {
            return userMapper.getLoginUser(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
    @Override
	public void addUser(User user) throws Exception {
    	try {
            userMapper.addUser(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
		
	}
    @Override
	public List<User> showGoods(User user) throws Exception {
    	try {
            return userMapper.showGoods(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}

    @Override
	public List<User> showInfo(User user) throws Exception {
    	try {
            return userMapper.showInfo(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
    @Override
	public List<User> showIndexImage(User user) throws Exception {
    	try {
            return userMapper.showIndexImage(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
    
    @Override
	public void addCar(User user) throws Exception {
		// TODO Auto-generated method stub
    	try {
            userMapper.addCar(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
		
	}
    

	
	@Override
	public List<User> showCar(User user) throws Exception {
		try {
            return userMapper.showCar(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	@Override
	public List<User> showCar1(User user) throws Exception {
		try {
            return userMapper.showCar1(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	
	
	@Override
	public void delCar(User user) throws Exception {
		// TODO Auto-generated method stub
    	try {
            userMapper.delCar(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
		
	}
        
	@Override
	public List<User> checkCar(User user) throws Exception {
		try {
            return userMapper.checkCar(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	@Override
	public void jia(User user) throws Exception {
		try {
            userMapper.jia(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	
	@Override
	public void addOrder(User user) throws Exception {
		try {
            userMapper.addOrder(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
		
	}
		@Override
	public void clear(User user) throws Exception {
			try {
	            userMapper.clear(user);
	        } catch (RuntimeException e) {
	            e.printStackTrace();
	            throw e;
	        }
		
	}

	@Override
	public List<User> SumPrice(User user) throws Exception {
		try {
            return userMapper.SumPrice(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	public List<User> SumPrice1(User user) throws Exception {
		try {
            return userMapper.SumPrice1(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	@Override
	public void addGb(User user) throws Exception {
		try {
            userMapper.addGb(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
		
	}

	@Override
	public void updateGb(User user) throws Exception {
		try {
            userMapper.updateGb(user);;
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
		
	}
	@Override
	public List<User> selGb(User user) throws Exception {
		try {
            return userMapper.selGb(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}	
	@Override
	public void updateFlag(User user) throws Exception {
		try {
            userMapper.updateFlag(user);;
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
		
	}
	@Override
	public List<User> head(User user) throws Exception {
		try {
            return userMapper.head(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	  public List<User> phoneCheck(User user) throws Exception  {
			try {
	            return userMapper.phoneCheck(user);
	        } catch (RuntimeException e) {
	            e.printStackTrace();
	            throw e;
	        }
		}
    public UserMapper getUserMapper() {
        return userMapper;
    }

    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }
	@Override
	public List<User> selLuck(User user) throws Exception {
		try {
            return userMapper.selLuck(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	@Override
	public List<User> selLuck1(User user) throws Exception {
		try {
            return userMapper.selLuck1(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	@Override
	public void acquiryLuck(User user) throws Exception {
		try {
            userMapper.acquiryLuck(user);;
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
		
	}
	@Override
	public void useLuck(User user) throws Exception {
		// TODO Auto-generated method stub
		try {
            userMapper.useLuck(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	@Override
	public void updatePay(User user) throws Exception {
		try {
            userMapper.updatePay(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
		
	}
	@Override
	public List<User> showAllOrder(User user) throws Exception {
		try {
           return userMapper.showAllOrder(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	@Override
	public void addminAdd(User user) throws Exception {
		try {
	           userMapper.addminAdd(user);
	        } catch (RuntimeException e) {
	            e.printStackTrace();
	            throw e;
	        }
		
	}
	@Override
	public void addminupdate(User user) throws Exception {
		try {
	          userMapper.addminupdate(user);
	        } catch (RuntimeException e) {
	            e.printStackTrace();
	            throw e;
	        }
		
	}
	@Override
	public void addmindelete(User user) throws Exception {
		try {
	          userMapper.addmindelete(user);
	        } catch (RuntimeException e) {
	            e.printStackTrace();
	            throw e;
	        }
		
	}
	@Override
	public List<User> showIndexImage1(User user) throws Exception {
		try {
            return userMapper.showIndexImage1(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            throw e;
        }
	}
	
	
	



	

}
