package com.foodshop.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.foodshop.pojo.User;
import com.foodshop.service.user.Sub;
import com.foodshop.service.user.UserService;
//ע��Ļ�������
@Controller
public class CarController {
	private Logger logger=Logger.getLogger(LoginController.class);
	@RequestMapping(value="/car")
	public String Login() throws Exception {
		logger.debug("����ע��========================");
		return("car");
	}
	//���ӹ��ﳵ
	@RequestMapping(value="/doCar")
	public void AddCar(@RequestParam(value="id")int id,HttpServletRequest request,HttpServletResponse resposes)throws Exception {
		logger.debug("�������ﳵ======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        List<User> check = new ArrayList<User>();
        User userCondition = new User();
        HttpSession session=request.getSession();
        int Sum=1;
        String UserName=session.getAttribute("UserName").toString();
        userCondition.setGoodsId(id);
       
        userCondition.setUserName(UserName);
        
        check=userService.checkCar(userCondition);
        if(check.size()!=0) {      
             for (User userResult : check) {
             	Sum=userResult.getSum()+1;      
             }
             userCondition.setSum(Sum);
             userService.jia(userCondition);
        	
        } else {
        userCondition.setSum(Sum);
        userService.addCar(userCondition);
        userList=userService.showCar(userCondition);
        request.setAttribute("userList", userList);
        }
        request.getRequestDispatcher("/showCar").forward(request, resposes);
        
	}
	//��ʾ��Ʒ
	@RequestMapping(value="/showCar")
	public void showCar(HttpServletRequest request,HttpServletResponse resposes)throws Exception {
		logger.debug("�������ﳵ======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        List<User> luckList = new ArrayList<User>();
       
        User userCondition = new User();
        HttpSession session=request.getSession();
        
        String UserName=session.getAttribute("UserName").toString();
 //       userCondition.setGoodsId(id);
        userCondition.setClear(0);
        userCondition.setUserName(UserName);
//        userService.addCar(userCondition);
        
        
        userList=userService.showCar(userCondition);
        request.setAttribute("userList", userList);
        int SumPrice=0;
        
        for (User userResult : userList) {
        	
        	int Sum=(int) (userResult.getSum())*(int)(userResult.getPrice());
           SumPrice+=Sum;
        }
        //��ʾ���˺��
        int luck=0;
       luckList= userService.selLuck1(userCondition);
       request.setAttribute("luckList", luckList);       
        //��999�����
        int ze=SumPrice;
        if(SumPrice>999) {
        	SumPrice*=0.8;
        }
        ze=ze-SumPrice-luck;
        request.setAttribute("SumPrice", SumPrice);
        request.setAttribute("ze", ze);
        request.getRequestDispatcher("/car").forward(request, resposes);    
	}
	//ɾ�����ﳵ
	@RequestMapping(value="/delCar")
	public void delCar(@RequestParam(value="id")int id,HttpServletRequest request,HttpServletResponse resposes)throws Exception {
		logger.debug("�������ﳵ======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        User userCondition = new User();
        HttpSession session=request.getSession();
        String UserName=session.getAttribute("UserName").toString();
        userCondition.setGoodsId(id);
        userService.delCar(userCondition);

        request.getRequestDispatcher("/showCar").forward(request, resposes);
        
	}
	//+1
	@RequestMapping(value="/jia")
	public void doJia(@RequestParam int GoodsId,HttpServletRequest request,HttpServletResponse response)throws Exception {
		logger.debug("������¼======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        User userCondition = new User();
        HttpSession session=request.getSession();
        String UserName=session.getAttribute("UserName").toString();
        userCondition.setGoodsId(GoodsId);
        userCondition.setUserName(UserName);
        userList=userService.checkCar(userCondition);
        int Sum=1;
        for (User userResult : userList) {
        	Sum=userResult.getSum()+1;
           
        }
        userCondition.setSum(Sum);
        userService.jia(userCondition);
        
        request.getRequestDispatcher("/showCar").forward(request, response);
       
	}
	//-1
	@RequestMapping(value="/jian")
	public void doJian(@RequestParam int GoodsId,HttpServletRequest request,HttpServletResponse response)throws Exception {
		logger.debug("������¼======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        User userCondition = new User();
        HttpSession session=request.getSession();
        String UserName=session.getAttribute("UserName").toString();
        userCondition.setGoodsId(GoodsId);
        userCondition.setUserName(UserName);
        userList=userService.checkCar(userCondition);
        int Sum=1;
        for (User userResult : userList) {
        	Sum=userResult.getSum()-1;
        }
        userCondition.setSum(Sum);
        userService.jia(userCondition);
        
        request.getRequestDispatcher("/showCar").forward(request, response);
	}
	//ʹ�ú��
	@RequestMapping(value="/useLuck")
	public void useLuck(HttpServletRequest request,HttpServletResponse response)throws Exception {
		logger.debug("ʹ�ú��======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        int luckId=Integer.parseInt(request.getParameter("luckId").toString());
        String un="";
        String usen="";
        User userCondition = new User();
        HttpSession session=request.getSession();
        String UserName=session.getAttribute("UserName").toString();
        userCondition.setLuckId(luckId);
        userCondition.setClear(0);
        userCondition.setUserName(UserName);
        userList= userService.selLuck1(userCondition);
        for(User userResult:userList) {
        	un=userResult.getUsen();
        }
        usen=UserName+","+un;
        userCondition.setUsen(usen);
        
        userService.useLuck(userCondition);
        
        
        PrintWriter out =response.getWriter(); 
		out.println("<script>");
	    out.println("history.back();");
	    out.println("</script>");
	}
	
}
