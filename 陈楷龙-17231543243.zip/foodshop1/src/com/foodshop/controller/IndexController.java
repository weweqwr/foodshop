package com.foodshop.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.foodshop.pojo.User;
import com.foodshop.service.user.UserService;
//�̳ǵĻ�������
@Controller
public class IndexController{
	private Logger logger=Logger.getLogger(LoginController.class);
	
	@RequestMapping(value="/sindex")
	public String Login() throws Exception {
		logger.debug("�����¼����========================");
		return("sindex");
	}
	//��Ʒ����ҳ��
	@RequestMapping(value="/doIndex")
	public void doLoging(HttpServletRequest request,HttpServletResponse resposes,HttpSession session)throws Exception {
		logger.debug("����ע��======================");
		ModelAndView  mView=new ModelAndView();
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        User userCondition = new User();
        userCondition.setIndexnShow(1);;
        userList=userService.showIndexImage(userCondition);      
        request.setAttribute("userList", userList);   
        request.getRequestDispatcher("/sindex").forward(request, resposes);
 
//        resposes.sendRedirect("/information");
	}
	//ģ����ѯ
	@RequestMapping(value="/doIndex1",method=RequestMethod.POST)
	public void doLoging1(@RequestParam String GoodsName,HttpServletRequest request,HttpServletResponse resposes,HttpSession session)throws Exception {
		logger.debug("����ע��======================");
		ModelAndView  mView=new ModelAndView();
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        User userCondition = new User();
        userCondition.setIndexnShow(1);
        userCondition.setGoodsName(GoodsName);
        userList=userService.showIndexImage1(userCondition);      
        request.setAttribute("userList", userList);   
        request.getRequestDispatcher("/sindex").forward(request, resposes);
 
//        resposes.sendRedirect("/information");
	}
}