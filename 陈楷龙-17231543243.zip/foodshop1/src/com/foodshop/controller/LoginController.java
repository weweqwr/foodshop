

package com.foodshop.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.foodshop.pojo.User;
import com.foodshop.service.user.UserService;
//��¼�����Ĺ���
@Controller
public class LoginController {
	private Logger logger=Logger.getLogger(LoginController.class);
	@RequestMapping(value="/Login")
	public String Login() throws Exception {
		logger.debug("�����¼����========================");
		return("Login");
	}
	
	
	@RequestMapping(value="/doLogin",method=RequestMethod.POST)
	public void doLoging(@RequestParam String UserName,@RequestParam String PassWord,HttpServletRequest request,HttpServletResponse resposes)throws Exception {
		logger.debug("������¼======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        User userCondition = new User();
        userCondition.setUserName(UserName);
        userCondition.setPassWord(PassWord);
        userList = userService.findUser(userCondition);
        if(userList.size()!=0) {
        	HttpSession session=request.getSession();
        	session.setAttribute("UserName", UserName);
        	session.setAttribute("PassWord", PassWord);
        	request.getRequestDispatcher("/doIndex").forward(request, resposes);
        }else {
        	PrintWriter out = resposes.getWriter();
        	out.println("<script>");
  		    out.println("alert('�û��������벻��ȷ');");
  		    out.println("history.back();");
  		    out.println("</script>");
        	
        	//request.getRequestDispatcher("/Login").forward(request, resposes);
        }
	}
}
