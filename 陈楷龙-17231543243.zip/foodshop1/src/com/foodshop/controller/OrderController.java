package com.foodshop.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.foodshop.pojo.User;
import com.foodshop.service.user.UserService;
//�̳ǵĻ�������
@Controller
public class OrderController{
	private Logger logger=Logger.getLogger(LoginController.class);
	
	@RequestMapping(value="/order")
	public String Login() throws Exception {
		logger.debug("�����¼����========================");
		return("order");
	}
	@RequestMapping(value="/order2")
	public String Login2() throws Exception {
		logger.debug("�����¼����========================");
		return("order2");
	}
	//�ύ����
	@RequestMapping(value="/doOrder")
	public void doOrderr(@RequestParam int SumPrice,HttpServletRequest request,HttpServletResponse resposes)throws Exception {
		logger.debug("�������ﳵ======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        User userCondition = new User();
        HttpSession session=request.getSession();
        String UserName=session.getAttribute("UserName").toString();
        userCondition.setPay(0);//0δ֧��
        userCondition.setUserName(UserName);
        userCondition.setSumPrice(SumPrice);
        userService.addOrder(userCondition);
        userService.clear(userCondition);
        request.getRequestDispatcher("/showOrder").forward(request, resposes);
	}
	//��ʾ��Ʒ
	@RequestMapping(value="/showOrder")
	public void showOrder(HttpServletRequest request,HttpServletResponse resposes)throws Exception {
		logger.debug("������ʾ======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        List<User> Sumprice = new ArrayList<User>();
        User userCondition = new User();
        String OrderId="";
        HttpSession session=request.getSession();  
        String UserName=session.getAttribute("UserName").toString();
        userCondition.setClear(1); 
        userCondition.setUserName(UserName);
        
        userList=userService.showCar1(userCondition);
        Sumprice =userService.SumPrice1(userCondition);
        for(User result:userList) {
        	OrderId=result.getOrderId().toString();
        }
        request.setAttribute("userList", userList);
        request.setAttribute("Sumprice", Sumprice);
        
        
        request.getRequestDispatcher("/order").forward(request, resposes);
        
	}
	//��ʾδ�������ж���
	@RequestMapping(value="/showAllOrder")
	public void showAllOrder(HttpServletRequest request,HttpServletResponse resposes)throws Exception {
		logger.debug("������ʾ======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        List<User> Sumprice = new ArrayList<User>();
        User userCondition = new User();
        String OrderId="";
        HttpSession session=request.getSession();  
        String UserName=session.getAttribute("UserName").toString();
        userCondition.setClear(1); 
        userCondition.setUserName(UserName);
        
        userList=userService.showAllOrder(userCondition);
        Sumprice =userService.SumPrice1(userCondition);
        for(User result:userList) {
        	OrderId=result.getOrderId().toString();
        }
        request.setAttribute("userList", userList);
        request.setAttribute("Sumprice", Sumprice);
     
        
        request.getRequestDispatcher("/order2").forward(request, resposes);
        
	}
}
