package com.foodshop.controller;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.foodshop.pojo.User;
import com.foodshop.service.user.UserService;
@Controller
public class adminController {
	
		private Logger logger=Logger.getLogger(LoginController.class);
		@RequestMapping(value="/admin")
	public String Login() throws Exception {
		logger.debug("�����¼����========================");
		return("admin");
	}
		@RequestMapping(value="/admin2")
		public String Login2() throws Exception {
			logger.debug("�����¼����========================");
			return("admin2");
		}
			@RequestMapping(value="/admin3")
		public String Login3() throws Exception {
			logger.debug("�����¼����========================");
			return("admin3");
		}
	@RequestMapping(value="/adminAdd",method=RequestMethod.POST)
	public void doLoging(@RequestParam int GoodsId,@RequestParam String GoodsName,@RequestParam int price,@RequestParam String Address,
			@RequestParam int InfoShow,@RequestParam int IndexnShow,HttpServletRequest request,HttpServletResponse responses,HttpSession session)throws Exception  {
		logger.debug("����ע��======================");
		ModelAndView  mView=new ModelAndView();
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");

	User userCondition = new User();
	userCondition.setGoodsId(GoodsId);
	userCondition.setGoodsName(GoodsName);
	userCondition.setPrice(price);
	userCondition.setAddress(Address);
	
	userCondition.setInfoShow(InfoShow);
	userCondition.setIndexnShow(IndexnShow);
	userService.addminAdd(userCondition);
	PrintWriter out =responses.getWriter(); 
	out.println("<script>");
    out.println("history.back();");
    out.println("alert('���ӳɹ�');");
    out.println("</script>");
	
	}

	@RequestMapping(value="/admindelete",method=RequestMethod.POST)
	public void admindelete(@RequestParam int GoodsId,HttpServletRequest request,HttpServletResponse responses,HttpSession session)throws Exception  {
		logger.debug("����ע��======================");
		ModelAndView  mView=new ModelAndView();
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");

	User userCondition = new User();
	userCondition.setGoodsId(GoodsId);
	userService.addmindelete(userCondition);
	PrintWriter out =responses.getWriter(); 
	out.println("<script>");
    out.println("history.back();");
    out.println("alert('ɾ���ɹ�');");
    out.println("</script>");
	
	}
	@RequestMapping(value="/adminupdate",method=RequestMethod.POST)
	public void adminupdate(@RequestParam int GoodsId,@RequestParam String GoodsName,@RequestParam int price,HttpServletRequest request,HttpServletResponse responses,HttpSession session)throws Exception  {
		logger.debug("����ע��======================");
		ModelAndView  mView=new ModelAndView();
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");

	User userCondition = new User();
	userCondition.setGoodsId(GoodsId);
	userCondition.setGoodsName(GoodsName);
	userCondition.setPrice(price);
	userService.addminupdate(userCondition);
	PrintWriter out =responses.getWriter(); 
	out.println("<script>");
    out.println("history.back();");
    out.println("alert('�޸ĳɹ�');");
    out.println("</script>");
	}
}
