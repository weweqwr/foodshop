package com.foodshop.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.RestTest;
import com.foodshop.pojo.User;
import com.foodshop.service.user.UserService;
//��¼�����Ĺ���
@Controller
public class LoginPhoneController {
	private Logger logger=Logger.getLogger(LoginPhoneController.class);
	String s="1";
	String UserName1="";
	@RequestMapping(value="/phoneLogin")
	public String Login() throws Exception {
		logger.debug("�����¼����========================");
		return("phoneLogin");
	}
	
	
	@RequestMapping(value="/doPhoneLogin",method=RequestMethod.POST)
	public void doLoging(@RequestParam String UserName,@RequestParam String phoneCheck,HttpServletRequest request,HttpServletResponse resposes)throws Exception {
		System.out.println(UserName);
		logger.debug("������¼======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
   //     String UserName1="";
        List<User> userList = new ArrayList<User>();
        User userCondition = new User();
        userCondition.setUserName(UserName);
        userList = userService.phoneCheck(userCondition);

//        
        if(s.equals(phoneCheck)) {
	        if(userList.size()!=0&&UserName1.equals(UserName)) {
	        	HttpSession session=request.getSession();
	        	session.setAttribute("UserName", UserName);
	        	request.getRequestDispatcher("/doIndex").forward(request, resposes);
	        }else {
	        	request.setAttribute("error", "�û��������벻��ȷ");
	        	request.getRequestDispatcher("/phoneLogin").forward(request, resposes);
	        }
        }
		if(phoneCheck.contentEquals("")||phoneCheck==null) {
        	RestTest rs=new RestTest();
    		s=rs.getFourRandom();
            rs.PhoneCheck(UserName,s);
         for(User userResult:userList) {
    	   UserName1=userResult.getUserName();
        }
        	request.setAttribute("error", "��֤�벻��ȷ");
        	request.getRequestDispatcher("/phoneLogin").forward(request, resposes);
        }
	}

}
