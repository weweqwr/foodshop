package com.foodshop.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.foodshop.pojo.User;
import com.foodshop.service.user.UserService;
//ע��Ļ�������
@Controller
public class RegisterController {
	private Logger logger=Logger.getLogger(LoginController.class);
	@RequestMapping(value="/register")
	public String Login() throws Exception {
		logger.debug("����ע��========================");
		return("register");
	}
	@RequestMapping(value="/doRegister",method=RequestMethod.POST)
	public String doLoging(@RequestParam String UserName,@RequestParam String PassWord,@RequestParam String PassWord1,HttpServletResponse response,HttpServletRequest request,HttpSession session)throws Exception {
		logger.debug("����ע��======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        User userCondition = new User();
        
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
  
        
        if(UserName.equals("")&&UserName==null&&PassWord.equals("")&&PassWord==null) {
        	PrintWriter out = response.getWriter();
        	 out.println("<script>");
   		    out.println("alert('���벻��Ϊ��');");
   		    out.println("history.back();");
   		    out.println("</script>");
        	return ("register");
        }else {
        	if(PassWord.equals(PassWord1)) {
        	PrintWriter out = response.getWriter();
        	userCondition.setUserName(UserName);
            userCondition.setPassWord(PassWord);
        	userService.addUser(userCondition);
        	out.flush();
  		    out.println("<script>");
  		    out.println("alert('ע��ɹ�');");
  		    out.println("history.back();");
  		    out.println("</script>");
        	return("Login");
        	}else {
        		  response.setContentType("text/html; charset=UTF-8"); //ת��
        		    PrintWriter out = response.getWriter();
        		    out.flush();
        		    out.println("<script>");
        		    out.println("alert('�������һ��');");
        		    out.println("history.back();");
        		    out.println("</script>");
        		 
        		return ("register");
        	}
        }
        
	}
}
