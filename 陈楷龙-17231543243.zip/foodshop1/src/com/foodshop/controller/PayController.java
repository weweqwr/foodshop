package com.foodshop.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.foodshop.pojo.User;
import com.foodshop.service.user.UserService;
//�̳ǵĻ�������
@Controller
public class PayController{
	private Logger logger=Logger.getLogger(LoginController.class);
	
	@RequestMapping(value="/index")
	public String Login() throws Exception {
		logger.debug("�����¼����========================");
		return("index");
	}
	
	//֧������
	@RequestMapping(value="/PayIndex")
	public void showOrder(HttpServletRequest request,HttpServletResponse resposes)throws Exception {
		logger.debug("������ʾ======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        List<User> Sumprice = new ArrayList<User>();
        List<User> usenList = new ArrayList<User>();
        User userCondition = new User();
        String OrderId="";
       
        HttpSession session=request.getSession();  
        String UserName=session.getAttribute("UserName").toString();
        userCondition.setClear(1);
        userCondition.setUserName(UserName);
        
        
        userList=userService.showCar1(userCondition);
        Sumprice =userService.SumPrice1(userCondition);
        
        request.setAttribute("userList", userList);
        request.setAttribute("Sumprice", Sumprice);
        
        
        request.getRequestDispatcher("/index").forward(request, resposes);
        
	}
	@RequestMapping(value="/updatePay")
	public void updatePay(@RequestParam int OrderId,HttpServletRequest request,HttpServletResponse resposes)throws Exception {
		logger.debug("������ʾ======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
		HttpSession session=request.getSession();
		
        UserService userService = (UserService) ctx.getBean("userService");
        User userCondition = new User();
        userCondition.setOrderId(OrderId);
        userService.updatePay(userCondition);
        request.getRequestDispatcher("/doIndex").forward(request, resposes);
	}
}