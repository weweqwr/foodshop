package com.foodshop.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.foodshop.pojo.User;
import com.foodshop.service.user.Sub;
import com.foodshop.service.user.UserService;
//�̳ǵĻ�������
@Controller
public class BaseController{
	private Logger logger=Logger.getLogger(LoginController.class);
	String url="";
	String a="";
	@RequestMapping(value="/Information")
	public String Login() throws Exception {
		logger.debug("�����¼����========================");
		return("Information");
	}
	//��Ʒ����ҳ��
	@RequestMapping(value="/getInformation")
	public void doLoging(@RequestParam(value="id")int id,HttpServletRequest request,HttpServletResponse resposes,HttpSession session)throws Exception {
		logger.debug("����ע��======================");
		ModelAndView  mView=new ModelAndView();
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        List<User> userList = new ArrayList<User>();
        List<User> userInfo = new ArrayList<User>();
        List<User> userImage = new ArrayList<User>();
        List<User> luck=new ArrayList<User>();
        User userCondition = new User();
        userCondition.setGoodsId(id);
        userCondition.setInfoShow(1);
        userList=userService.showGoods(userCondition);
        userInfo=userService.showInfo(userCondition);
        userCondition.setInfoShow(null);
        userImage=userService.showGoods(userCondition);
        luck=userService.selLuck(userCondition);
        request.setAttribute("userList", userList);
        request.setAttribute("userInfo", userInfo);
        request.setAttribute("userImage", userImage);
        request.setAttribute("luck", luck);
        url=request.getRequestURL()+"?id="+id;
        a=request.getServletPath()+"?id="+id;//��ת��id
        request.setAttribute("url",url);
        request.getRequestDispatcher("/Information").forward(request, resposes); 
//        resposes.sendRedirect("/information");
	}
//	����
	@RequestMapping(value="/getUrl")
	public void getUrl(HttpServletRequest request,HttpServletResponse resposes,HttpSession session)throws Exception {
		request.setAttribute("url",url);
		request.getRequestDispatcher(a).forward(request, resposes); 
	}
	//��ȡ���
	@RequestMapping(value="/acquiryLuck")
	public void acquiryLuck(@RequestParam(value="id")int id,@RequestParam(value="luckPrice")int luckPrice,HttpServletRequest request,HttpServletResponse resposes,HttpSession session)throws Exception {
		logger.debug("��ȡ���");
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
		 
		UserService userService = (UserService) ctx.getBean("userService");
		List<User> userList = new ArrayList<User>();
		List<String> checkName = new ArrayList<String>();
		User userCondition = new User();
		String UserNames="";
		int ShuLiang=0;
		String UserName=session.getAttribute("UserName").toString();
		 userCondition.setGoodsId(id);
		 userCondition.setLuckPrice(luckPrice);
		 userList=userService.selLuck(userCondition);
		 request.setCharacterEncoding("UTF-8");
	     resposes.setCharacterEncoding("UTF-8");
		 for(User userResult:userList) {
			UserNames= userResult.getUserName();
			ShuLiang=userResult.getShuLiang();
		 }
		 Sub sub=new Sub();
		 if(ShuLiang!=0) {//���ȫ������
			 checkName=sub.sub(UserNames);
				 if(userList.size()!=0&&!checkName.contains(UserName)) {//�ж��Ƿ�������
				ShuLiang-=1;
				 UserName=UserName+","+UserNames;
				userCondition.setUserName(UserName);
				userCondition.setShuLiang(ShuLiang);
				userService.acquiryLuck(userCondition);
				PrintWriter out = resposes.getWriter(); 
			 	out.println("<script>");
			 	out.println("alert('�ɹ���ȡ5Ԫ���');");
			    out.println("history.back();");
			    out.println("</script>");
			}else {
				PrintWriter out = resposes.getWriter(); 
				out.println("<script>");
				out.println("alert('һ���˻�ֻ����ȡһ�����');");
			    out.println("history.back();");
			    out.println("</script>");
			}
		 }else {
			 PrintWriter out = resposes.getWriter(); 
				out.println("<script>");
				out.println("alert('��������̫���������ȫ������');");
			    out.println("history.back();");
			    out.println("</script>");
		 }	 
		 
			
	}
	
}
