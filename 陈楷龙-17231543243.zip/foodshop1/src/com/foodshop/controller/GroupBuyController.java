package com.foodshop.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.foodshop.pojo.User;
import com.foodshop.service.user.Sub;
import com.foodshop.service.user.UserService;
//�Ź�����
@Controller
public class GroupBuyController {
	private Logger logger=Logger.getLogger(LoginController.class);
	@RequestMapping(value="/gb")
	public String gb(@RequestParam int id) throws Exception {
		logger.debug("����ע��========================");
		return("GroupBuy");
	}
	@RequestMapping(value="/doGb")
	public void doGb(@RequestParam int id,HttpServletRequest request,HttpServletResponse response)throws Exception {
//		logger.debug("�������ﳵ======================");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        User userCondition = new User();
        Sub s=new Sub();
		 List<User> userList = new ArrayList<User>();
		 List<User> userList1 = new ArrayList<User>();
		 List<String> userInfo= new ArrayList<String>();
		 List<User> head= new ArrayList<User>();
		 HttpSession session=request.getSession();
		 String UserName= session.getAttribute("UserName").toString();
		 String uname="";//�����û���
		 userList=userService.selGb(userCondition);
		 int i=0;
		 if(userList.size()!=0) {
			 for (User userResult : userList) {
				 
				  i=userResult.getFlag1();
				  System.out.print("+++++++++++++++++++++++"+i+"++++++++++++++++++++++++++");
				  userCondition.setFlag(i);
				  if(i==4) {
					  UserName=UserName+",";
					  userCondition.setUserName(UserName);
					  userService.updateFlag(userCondition);
					  userService.addGb(userCondition); 
					  //������빺�ﳵ
					  
				  }else if(i!=4) {
					  String name=","+userResult.getUserName();
					  UserName=UserName+name;
					  userCondition.setUserName(UserName);
					  i=i+1;
					  userCondition.setFlag1(i);
					  userService.updateGb(userCondition);
				  }
				  uname=userResult.getUserName();
			 }
		 }else if(userList.size()==0) {
			 UserName=UserName+",";
			 userCondition.setUserName(UserName);
			 userService.addGb(userCondition); 
		 }
		 
		 userList1=userService.selGb(userCondition);
		 for (User userResult : userList1) {
			 uname=userResult.getUserName();
		 }
		 		 
		 userInfo=s.sub(uname);
		 for(int a=0;a<userInfo.size();a++) {
			 userCondition.setUserName(userInfo.get(a));
			 head=userService.head(userCondition);
			 for (User userResult : head) {
				 request.setAttribute("UserName"+a, userResult.getUserMc()); 
				 request.setAttribute("UserHead"+a, userResult.getUserHead()); 
			 }
			 
		 }
		 
		 request.getRequestDispatcher("/gb").forward(request, response);
		 
	}
	
	@RequestMapping(value="/showGb")
	public void showGb(@RequestParam int id,HttpServletRequest request,HttpServletResponse response)throws Exception {
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        UserService userService = (UserService) ctx.getBean("userService");
        User userCondition = new User();
        List<String> userInfo= new ArrayList<String>();
        List<User> userList = new ArrayList<User>();
        List<User> head= new ArrayList<User>();
        String uname="";
        Sub s=new Sub();
        userList=userService.selGb(userCondition);
        for (User userResult : userList) {
        	uname=userResult.getUserName();
        }
		 userInfo=s.sub(uname);
		 for(int a=0;a<userInfo.size();a++) {
			 userCondition.setUserName(userInfo.get(a));
			 head=userService.head(userCondition);
			 for (User userResult : head) {
				 request.setAttribute("UserName"+a, userResult.getUserMc()); 
				 request.setAttribute("UserHead"+a, userResult.getUserHead()); 
			 }
			 
		 }
		 HttpSession session=request.getSession();
		 session.setAttribute("id1", id);
		 request.getRequestDispatcher("/gb").forward(request, response);
		
	}

}
